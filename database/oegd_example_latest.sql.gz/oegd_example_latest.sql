-- -------------------------------------------------------------
-- TablePlus 6.0.0(550)
--
-- https://tableplus.com/
--
-- Database: postgres
-- Generation Time: 2024-05-02 18:01:26.2860
-- -------------------------------------------------------------


DROP TABLE IF EXISTS "public"."admin_permissions";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS admin_permissions_id_seq;

-- Table Definition
CREATE TABLE "public"."admin_permissions" (
    "id" int4 NOT NULL DEFAULT nextval('admin_permissions_id_seq'::regclass),
    "action" varchar(255),
    "action_parameters" jsonb,
    "subject" varchar(255),
    "properties" jsonb,
    "conditions" jsonb,
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."admin_permissions_role_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS admin_permissions_role_links_id_seq;

-- Table Definition
CREATE TABLE "public"."admin_permissions_role_links" (
    "id" int4 NOT NULL DEFAULT nextval('admin_permissions_role_links_id_seq'::regclass),
    "permission_id" int4,
    "role_id" int4,
    "permission_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."admin_roles";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS admin_roles_id_seq;

-- Table Definition
CREATE TABLE "public"."admin_roles" (
    "id" int4 NOT NULL DEFAULT nextval('admin_roles_id_seq'::regclass),
    "name" varchar(255),
    "code" varchar(255),
    "description" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."admin_users";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS admin_users_id_seq;

-- Table Definition
CREATE TABLE "public"."admin_users" (
    "id" int4 NOT NULL DEFAULT nextval('admin_users_id_seq'::regclass),
    "firstname" varchar(255),
    "lastname" varchar(255),
    "username" varchar(255),
    "email" varchar(255),
    "password" varchar(255),
    "reset_password_token" varchar(255),
    "registration_token" varchar(255),
    "is_active" bool,
    "blocked" bool,
    "prefered_language" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."admin_users_roles_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS admin_users_roles_links_id_seq;

-- Table Definition
CREATE TABLE "public"."admin_users_roles_links" (
    "id" int4 NOT NULL DEFAULT nextval('admin_users_roles_links_id_seq'::regclass),
    "user_id" int4,
    "role_id" int4,
    "role_order" float8,
    "user_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."articles";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS articles_id_seq;

-- Table Definition
CREATE TABLE "public"."articles" (
    "id" int4 NOT NULL DEFAULT nextval('articles_id_seq'::regclass),
    "title" varchar(255),
    "slug" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "published_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    "body" jsonb,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_atoms_icons";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_atoms_icons_id_seq;

-- Table Definition
CREATE TABLE "public"."components_atoms_icons" (
    "id" int4 NOT NULL DEFAULT nextval('components_atoms_icons_id_seq'::regclass),
    "label" varchar(255),
    "slug" varchar(255),
    "direction" varchar(255),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_blocks_ctas";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_blocks_ctas_id_seq;

-- Table Definition
CREATE TABLE "public"."components_blocks_ctas" (
    "id" int4 NOT NULL DEFAULT nextval('components_blocks_ctas_id_seq'::regclass),
    "label" varchar(255),
    "href" varchar(255),
    "type" varchar(255),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_blocks_ctas_components";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_blocks_ctas_components_id_seq;

-- Table Definition
CREATE TABLE "public"."components_blocks_ctas_components" (
    "id" int4 NOT NULL DEFAULT nextval('components_blocks_ctas_components_id_seq'::regclass),
    "entity_id" int4,
    "component_id" int4,
    "component_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_landing_page_button_cards";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_landing_page_button_cards_id_seq;

-- Table Definition
CREATE TABLE "public"."components_landing_page_button_cards" (
    "id" int4 NOT NULL DEFAULT nextval('components_landing_page_button_cards_id_seq'::regclass),
    "label" varchar(255),
    "url" varchar(255),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_landing_page_button_cards_components";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_landing_page_button_cards_components_id_seq;

-- Table Definition
CREATE TABLE "public"."components_landing_page_button_cards_components" (
    "id" int4 NOT NULL DEFAULT nextval('components_landing_page_button_cards_components_id_seq'::regclass),
    "entity_id" int4,
    "component_id" int4,
    "component_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_landing_page_button_teasers";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_landing_page_button_teasers_id_seq;

-- Table Definition
CREATE TABLE "public"."components_landing_page_button_teasers" (
    "id" int4 NOT NULL DEFAULT nextval('components_landing_page_button_teasers_id_seq'::regclass),
    "headline" varchar(255),
    "subline" varchar(255),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_landing_page_button_teasers_components";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_landing_page_button_teasers_components_id_seq;

-- Table Definition
CREATE TABLE "public"."components_landing_page_button_teasers_components" (
    "id" int4 NOT NULL DEFAULT nextval('components_landing_page_button_teasers_components_id_seq'::regclass),
    "entity_id" int4,
    "component_id" int4,
    "component_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_landing_page_content_cards";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_landing_page_content_cards_id_seq;

-- Table Definition
CREATE TABLE "public"."components_landing_page_content_cards" (
    "id" int4 NOT NULL DEFAULT nextval('components_landing_page_content_cards_id_seq'::regclass),
    "headline" varchar(255),
    "copy" text,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_landing_page_content_cards_components";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_landing_page_content_cards_components_id_seq;

-- Table Definition
CREATE TABLE "public"."components_landing_page_content_cards_components" (
    "id" int4 NOT NULL DEFAULT nextval('components_landing_page_content_cards_components_id_seq'::regclass),
    "entity_id" int4,
    "component_id" int4,
    "component_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_landing_page_ga_searches";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_landing_page_ga_searches_id_seq;

-- Table Definition
CREATE TABLE "public"."components_landing_page_ga_searches" (
    "id" int4 NOT NULL DEFAULT nextval('components_landing_page_ga_searches_id_seq'::regclass),
    "headline" varchar(255),
    "copy" text,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_landing_page_ga_searches_components";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_landing_page_ga_searches_components_id_seq;

-- Table Definition
CREATE TABLE "public"."components_landing_page_ga_searches_components" (
    "id" int4 NOT NULL DEFAULT nextval('components_landing_page_ga_searches_components_id_seq'::regclass),
    "entity_id" int4,
    "component_id" int4,
    "component_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_landing_page_stages";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_landing_page_stages_id_seq;

-- Table Definition
CREATE TABLE "public"."components_landing_page_stages" (
    "id" int4 NOT NULL DEFAULT nextval('components_landing_page_stages_id_seq'::regclass),
    "headline" varchar(255),
    "subline" varchar(255),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_landing_page_stages_components";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_landing_page_stages_components_id_seq;

-- Table Definition
CREATE TABLE "public"."components_landing_page_stages_components" (
    "id" int4 NOT NULL DEFAULT nextval('components_landing_page_stages_components_id_seq'::regclass),
    "entity_id" int4,
    "component_id" int4,
    "component_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_landing_page_teasers";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_landing_page_teasers_id_seq;

-- Table Definition
CREATE TABLE "public"."components_landing_page_teasers" (
    "id" int4 NOT NULL DEFAULT nextval('components_landing_page_teasers_id_seq'::regclass),
    "headline" varchar(255),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."components_landing_page_teasers_components";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS components_landing_page_teasers_components_id_seq;

-- Table Definition
CREATE TABLE "public"."components_landing_page_teasers_components" (
    "id" int4 NOT NULL DEFAULT nextval('components_landing_page_teasers_components_id_seq'::regclass),
    "entity_id" int4,
    "component_id" int4,
    "component_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."files";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS files_id_seq;

-- Table Definition
CREATE TABLE "public"."files" (
    "id" int4 NOT NULL DEFAULT nextval('files_id_seq'::regclass),
    "name" varchar(255),
    "alternative_text" varchar(255),
    "caption" varchar(255),
    "width" int4,
    "height" int4,
    "formats" jsonb,
    "hash" varchar(255),
    "ext" varchar(255),
    "mime" varchar(255),
    "size" numeric(10,2),
    "url" varchar(255),
    "preview_url" varchar(255),
    "provider" varchar(255),
    "provider_metadata" jsonb,
    "folder_path" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."files_folder_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS files_folder_links_id_seq;

-- Table Definition
CREATE TABLE "public"."files_folder_links" (
    "id" int4 NOT NULL DEFAULT nextval('files_folder_links_id_seq'::regclass),
    "file_id" int4,
    "folder_id" int4,
    "file_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."files_related_morphs";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS files_related_morphs_id_seq;

-- Table Definition
CREATE TABLE "public"."files_related_morphs" (
    "id" int4 NOT NULL DEFAULT nextval('files_related_morphs_id_seq'::regclass),
    "file_id" int4,
    "related_id" int4,
    "related_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."global_articles";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS global_articles_id_seq;

-- Table Definition
CREATE TABLE "public"."global_articles" (
    "id" int4 NOT NULL DEFAULT nextval('global_articles_id_seq'::regclass),
    "title" varchar(255),
    "slug" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "published_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."health_departments";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS health_departments_id_seq;

-- Table Definition
CREATE TABLE "public"."health_departments" (
    "id" int4 NOT NULL DEFAULT nextval('health_departments_id_seq'::regclass),
    "title" varchar(255),
    "street" varchar(255),
    "city" varchar(255),
    "contact" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "published_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    "phone" varchar(255),
    "fax" varchar(255),
    "zip_code" varchar(255),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."i18n_locale";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS i18n_locale_id_seq;

-- Table Definition
CREATE TABLE "public"."i18n_locale" (
    "id" int4 NOT NULL DEFAULT nextval('i18n_locale_id_seq'::regclass),
    "name" varchar(255),
    "code" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."landing_pages";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS landing_pages_id_seq;

-- Table Definition
CREATE TABLE "public"."landing_pages" (
    "id" int4 NOT NULL DEFAULT nextval('landing_pages_id_seq'::regclass),
    "title" varchar(255),
    "slug" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "published_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."landing_pages_components";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS landing_pages_components_id_seq;

-- Table Definition
CREATE TABLE "public"."landing_pages_components" (
    "id" int4 NOT NULL DEFAULT nextval('landing_pages_components_id_seq'::regclass),
    "entity_id" int4,
    "component_id" int4,
    "component_type" varchar(255),
    "field" varchar(255),
    "order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_api_token_permissions";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_api_token_permissions_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_api_token_permissions" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_api_token_permissions_id_seq'::regclass),
    "action" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_api_token_permissions_token_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_api_token_permissions_token_links_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_api_token_permissions_token_links" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_api_token_permissions_token_links_id_seq'::regclass),
    "api_token_permission_id" int4,
    "api_token_id" int4,
    "api_token_permission_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_api_tokens";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_api_tokens_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_api_tokens" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_api_tokens_id_seq'::regclass),
    "name" varchar(255),
    "description" varchar(255),
    "type" varchar(255),
    "access_key" varchar(255),
    "last_used_at" timestamp,
    "expires_at" timestamp,
    "lifespan" int8,
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_core_store_settings";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_core_store_settings_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_core_store_settings" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_core_store_settings_id_seq'::regclass),
    "key" varchar(255),
    "value" text,
    "type" varchar(255),
    "environment" varchar(255),
    "tag" varchar(255),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_database_schema";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_database_schema_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_database_schema" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_database_schema_id_seq'::regclass),
    "schema" json,
    "time" timestamp,
    "hash" varchar(255),
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_migrations";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_migrations_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_migrations" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_migrations_id_seq'::regclass),
    "name" varchar(255),
    "time" timestamp,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_release_actions";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_release_actions_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_release_actions" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_release_actions_id_seq'::regclass),
    "type" varchar(255),
    "target_id" int4,
    "target_type" varchar(255),
    "content_type" varchar(255),
    "locale" varchar(255),
    "is_entry_valid" bool,
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_release_actions_release_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_release_actions_release_links_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_release_actions_release_links" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_release_actions_release_links_id_seq'::regclass),
    "release_action_id" int4,
    "release_id" int4,
    "release_action_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_releases";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_releases_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_releases" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_releases_id_seq'::regclass),
    "name" varchar(255),
    "released_at" timestamp,
    "scheduled_at" timestamp,
    "timezone" varchar(255),
    "status" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_transfer_token_permissions";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_transfer_token_permissions_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_transfer_token_permissions" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_transfer_token_permissions_id_seq'::regclass),
    "action" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_transfer_token_permissions_token_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_transfer_token_permissions_token_links_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_transfer_token_permissions_token_links" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_transfer_token_permissions_token_links_id_seq'::regclass),
    "transfer_token_permission_id" int4,
    "transfer_token_id" int4,
    "transfer_token_permission_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_transfer_tokens";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_transfer_tokens_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_transfer_tokens" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_transfer_tokens_id_seq'::regclass),
    "name" varchar(255),
    "description" varchar(255),
    "access_key" varchar(255),
    "last_used_at" timestamp,
    "expires_at" timestamp,
    "lifespan" int8,
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."strapi_webhooks";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS strapi_webhooks_id_seq;

-- Table Definition
CREATE TABLE "public"."strapi_webhooks" (
    "id" int4 NOT NULL DEFAULT nextval('strapi_webhooks_id_seq'::regclass),
    "name" varchar(255),
    "url" text,
    "headers" jsonb,
    "events" jsonb,
    "enabled" bool,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."up_permissions";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS up_permissions_id_seq;

-- Table Definition
CREATE TABLE "public"."up_permissions" (
    "id" int4 NOT NULL DEFAULT nextval('up_permissions_id_seq'::regclass),
    "action" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."up_permissions_role_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS up_permissions_role_links_id_seq;

-- Table Definition
CREATE TABLE "public"."up_permissions_role_links" (
    "id" int4 NOT NULL DEFAULT nextval('up_permissions_role_links_id_seq'::regclass),
    "permission_id" int4,
    "role_id" int4,
    "permission_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."up_roles";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS up_roles_id_seq;

-- Table Definition
CREATE TABLE "public"."up_roles" (
    "id" int4 NOT NULL DEFAULT nextval('up_roles_id_seq'::regclass),
    "name" varchar(255),
    "description" varchar(255),
    "type" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."up_users";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS up_users_id_seq;

-- Table Definition
CREATE TABLE "public"."up_users" (
    "id" int4 NOT NULL DEFAULT nextval('up_users_id_seq'::regclass),
    "username" varchar(255),
    "email" varchar(255),
    "provider" varchar(255),
    "password" varchar(255),
    "reset_password_token" varchar(255),
    "confirmation_token" varchar(255),
    "confirmed" bool,
    "blocked" bool,
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."up_users_role_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS up_users_role_links_id_seq;

-- Table Definition
CREATE TABLE "public"."up_users_role_links" (
    "id" int4 NOT NULL DEFAULT nextval('up_users_role_links_id_seq'::regclass),
    "user_id" int4,
    "role_id" int4,
    "user_order" float8,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."upload_folders";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS upload_folders_id_seq;

-- Table Definition
CREATE TABLE "public"."upload_folders" (
    "id" int4 NOT NULL DEFAULT nextval('upload_folders_id_seq'::regclass),
    "name" varchar(255),
    "path_id" int4,
    "path" varchar(255),
    "created_at" timestamp,
    "updated_at" timestamp,
    "created_by_id" int4,
    "updated_by_id" int4,
    PRIMARY KEY ("id")
);

DROP TABLE IF EXISTS "public"."upload_folders_parent_links";
-- This script only contains the table creation statements and does not fully represent the table in the database. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS upload_folders_parent_links_id_seq;

-- Table Definition
CREATE TABLE "public"."upload_folders_parent_links" (
    "id" int4 NOT NULL DEFAULT nextval('upload_folders_parent_links_id_seq'::regclass),
    "folder_id" int4,
    "inv_folder_id" int4,
    "folder_order" float8,
    PRIMARY KEY ("id")
);

INSERT INTO "public"."admin_permissions" ("id", "action", "action_parameters", "subject", "properties", "conditions", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, 'plugin::content-manager.explorer.create', '{}', 'api::article.article', '{"fields": ["Title", "Slug"]}', '[]', '2024-05-02 14:15:55.755', '2024-05-02 14:15:55.755', NULL, NULL),
(2, 'plugin::content-manager.explorer.create', '{}', 'api::global-article.global-article', '{"fields": ["Title", "Slug"]}', '[]', '2024-05-02 14:15:56.029', '2024-05-02 14:15:56.029', NULL, NULL),
(3, 'plugin::content-manager.explorer.read', '{}', 'api::article.article', '{"fields": ["Title", "Slug"]}', '[]', '2024-05-02 14:15:56.31', '2024-05-02 14:15:56.31', NULL, NULL),
(4, 'plugin::content-manager.explorer.read', '{}', 'api::global-article.global-article', '{"fields": ["Title", "Slug"]}', '[]', '2024-05-02 14:15:56.601', '2024-05-02 14:15:56.601', NULL, NULL),
(5, 'plugin::content-manager.explorer.update', '{}', 'api::article.article', '{"fields": ["Title", "Slug"]}', '[]', '2024-05-02 14:15:56.887', '2024-05-02 14:15:56.887', NULL, NULL),
(6, 'plugin::content-manager.explorer.update', '{}', 'api::global-article.global-article', '{"fields": ["Title", "Slug"]}', '[]', '2024-05-02 14:15:57.171', '2024-05-02 14:15:57.171', NULL, NULL),
(7, 'plugin::content-manager.explorer.delete', '{}', 'api::article.article', '{}', '[]', '2024-05-02 14:15:57.404', '2024-05-02 14:15:57.404', NULL, NULL),
(8, 'plugin::content-manager.explorer.delete', '{}', 'api::global-article.global-article', '{}', '[]', '2024-05-02 14:15:57.689', '2024-05-02 14:15:57.689', NULL, NULL),
(9, 'plugin::content-manager.explorer.publish', '{}', 'api::article.article', '{}', '[]', '2024-05-02 14:15:57.967', '2024-05-02 14:15:57.967', NULL, NULL),
(10, 'plugin::content-manager.explorer.publish', '{}', 'api::global-article.global-article', '{}', '[]', '2024-05-02 14:15:58.261', '2024-05-02 14:15:58.261', NULL, NULL),
(11, 'plugin::upload.read', '{}', NULL, '{}', '[]', '2024-05-02 14:15:58.549', '2024-05-02 14:15:58.549', NULL, NULL),
(12, 'plugin::upload.configure-view', '{}', NULL, '{}', '[]', '2024-05-02 14:15:58.827', '2024-05-02 14:15:58.827', NULL, NULL),
(13, 'plugin::upload.assets.create', '{}', NULL, '{}', '[]', '2024-05-02 14:15:59.115', '2024-05-02 14:15:59.115', NULL, NULL),
(14, 'plugin::upload.assets.update', '{}', NULL, '{}', '[]', '2024-05-02 14:15:59.397', '2024-05-02 14:15:59.397', NULL, NULL),
(15, 'plugin::upload.assets.download', '{}', NULL, '{}', '[]', '2024-05-02 14:15:59.673', '2024-05-02 14:15:59.673', NULL, NULL),
(16, 'plugin::upload.assets.copy-link', '{}', NULL, '{}', '[]', '2024-05-02 14:15:59.954', '2024-05-02 14:15:59.954', NULL, NULL),
(17, 'plugin::content-manager.explorer.create', '{}', 'api::article.article', '{"fields": ["Title", "Slug"]}', '["admin::is-creator"]', '2024-05-02 14:16:00.244', '2024-05-02 14:16:00.244', NULL, NULL),
(18, 'plugin::content-manager.explorer.create', '{}', 'api::global-article.global-article', '{"fields": ["Title", "Slug"]}', '["admin::is-creator"]', '2024-05-02 14:16:00.529', '2024-05-02 14:16:00.529', NULL, NULL),
(19, 'plugin::content-manager.explorer.read', '{}', 'api::article.article', '{"fields": ["Title", "Slug"]}', '["admin::is-creator"]', '2024-05-02 14:16:00.766', '2024-05-02 14:16:00.766', NULL, NULL),
(20, 'plugin::content-manager.explorer.read', '{}', 'api::global-article.global-article', '{"fields": ["Title", "Slug"]}', '["admin::is-creator"]', '2024-05-02 14:16:01.047', '2024-05-02 14:16:01.047', NULL, NULL),
(21, 'plugin::content-manager.explorer.update', '{}', 'api::article.article', '{"fields": ["Title", "Slug"]}', '["admin::is-creator"]', '2024-05-02 14:16:01.325', '2024-05-02 14:16:01.325', NULL, NULL),
(22, 'plugin::content-manager.explorer.update', '{}', 'api::global-article.global-article', '{"fields": ["Title", "Slug"]}', '["admin::is-creator"]', '2024-05-02 14:16:01.565', '2024-05-02 14:16:01.565', NULL, NULL),
(23, 'plugin::content-manager.explorer.delete', '{}', 'api::article.article', '{}', '["admin::is-creator"]', '2024-05-02 14:16:01.837', '2024-05-02 14:16:01.837', NULL, NULL),
(24, 'plugin::content-manager.explorer.delete', '{}', 'api::global-article.global-article', '{}', '["admin::is-creator"]', '2024-05-02 14:16:02.119', '2024-05-02 14:16:02.119', NULL, NULL),
(25, 'plugin::upload.read', '{}', NULL, '{}', '["admin::is-creator"]', '2024-05-02 14:16:02.36', '2024-05-02 14:16:02.36', NULL, NULL),
(26, 'plugin::upload.configure-view', '{}', NULL, '{}', '[]', '2024-05-02 14:16:02.64', '2024-05-02 14:16:02.64', NULL, NULL),
(27, 'plugin::upload.assets.create', '{}', NULL, '{}', '[]', '2024-05-02 14:16:02.873', '2024-05-02 14:16:02.873', NULL, NULL),
(28, 'plugin::upload.assets.update', '{}', NULL, '{}', '["admin::is-creator"]', '2024-05-02 14:16:03.17', '2024-05-02 14:16:03.17', NULL, NULL),
(29, 'plugin::upload.assets.download', '{}', NULL, '{}', '[]', '2024-05-02 14:16:03.455', '2024-05-02 14:16:03.455', NULL, NULL),
(30, 'plugin::upload.assets.copy-link', '{}', NULL, '{}', '[]', '2024-05-02 14:16:03.743', '2024-05-02 14:16:03.743', NULL, NULL),
(32, 'plugin::content-manager.explorer.create', '{}', 'api::global-article.global-article', '{"fields": ["Title", "Slug"]}', '[]', '2024-05-02 14:16:04.601', '2024-05-02 14:16:04.601', NULL, NULL),
(33, 'plugin::content-manager.explorer.create', '{}', 'plugin::users-permissions.user', '{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role"]}', '[]', '2024-05-02 14:16:04.879', '2024-05-02 14:16:04.879', NULL, NULL),
(35, 'plugin::content-manager.explorer.read', '{}', 'api::global-article.global-article', '{"fields": ["Title", "Slug"]}', '[]', '2024-05-02 14:16:05.464', '2024-05-02 14:16:05.464', NULL, NULL),
(36, 'plugin::content-manager.explorer.read', '{}', 'plugin::users-permissions.user', '{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role"]}', '[]', '2024-05-02 14:16:05.704', '2024-05-02 14:16:05.704', NULL, NULL),
(38, 'plugin::content-manager.explorer.update', '{}', 'api::global-article.global-article', '{"fields": ["Title", "Slug"]}', '[]', '2024-05-02 14:16:06.27', '2024-05-02 14:16:06.27', NULL, NULL),
(39, 'plugin::content-manager.explorer.update', '{}', 'plugin::users-permissions.user', '{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role"]}', '[]', '2024-05-02 14:16:06.555', '2024-05-02 14:16:06.555', NULL, NULL),
(40, 'plugin::content-manager.explorer.delete', '{}', 'api::article.article', '{}', '[]', '2024-05-02 14:16:06.838', '2024-05-02 14:16:06.838', NULL, NULL),
(41, 'plugin::content-manager.explorer.delete', '{}', 'api::global-article.global-article', '{}', '[]', '2024-05-02 14:16:07.12', '2024-05-02 14:16:07.12', NULL, NULL),
(42, 'plugin::content-manager.explorer.delete', '{}', 'plugin::users-permissions.user', '{}', '[]', '2024-05-02 14:16:07.411', '2024-05-02 14:16:07.411', NULL, NULL),
(43, 'plugin::content-manager.explorer.publish', '{}', 'api::article.article', '{}', '[]', '2024-05-02 14:16:07.671', '2024-05-02 14:16:07.671', NULL, NULL),
(44, 'plugin::content-manager.explorer.publish', '{}', 'api::global-article.global-article', '{}', '[]', '2024-05-02 14:16:07.964', '2024-05-02 14:16:07.964', NULL, NULL),
(45, 'plugin::content-manager.single-types.configure-view', '{}', NULL, '{}', '[]', '2024-05-02 14:16:08.274', '2024-05-02 14:16:08.274', NULL, NULL),
(46, 'plugin::content-manager.collection-types.configure-view', '{}', NULL, '{}', '[]', '2024-05-02 14:16:08.56', '2024-05-02 14:16:08.56', NULL, NULL),
(47, 'plugin::content-manager.components.configure-layout', '{}', NULL, '{}', '[]', '2024-05-02 14:16:08.864', '2024-05-02 14:16:08.864', NULL, NULL),
(48, 'plugin::content-type-builder.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:09.166', '2024-05-02 14:16:09.166', NULL, NULL),
(49, 'plugin::email.settings.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:09.465', '2024-05-02 14:16:09.465', NULL, NULL),
(50, 'plugin::upload.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:09.768', '2024-05-02 14:16:09.768', NULL, NULL),
(51, 'plugin::upload.assets.create', '{}', NULL, '{}', '[]', '2024-05-02 14:16:10.077', '2024-05-02 14:16:10.077', NULL, NULL),
(52, 'plugin::upload.assets.update', '{}', NULL, '{}', '[]', '2024-05-02 14:16:10.387', '2024-05-02 14:16:10.387', NULL, NULL),
(53, 'plugin::upload.assets.download', '{}', NULL, '{}', '[]', '2024-05-02 14:16:10.683', '2024-05-02 14:16:10.683', NULL, NULL),
(54, 'plugin::upload.assets.copy-link', '{}', NULL, '{}', '[]', '2024-05-02 14:16:10.979', '2024-05-02 14:16:10.979', NULL, NULL),
(55, 'plugin::upload.configure-view', '{}', NULL, '{}', '[]', '2024-05-02 14:16:11.222', '2024-05-02 14:16:11.222', NULL, NULL),
(56, 'plugin::upload.settings.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:11.509', '2024-05-02 14:16:11.509', NULL, NULL),
(57, 'plugin::i18n.locale.create', '{}', NULL, '{}', '[]', '2024-05-02 14:16:11.815', '2024-05-02 14:16:11.815', NULL, NULL),
(58, 'plugin::i18n.locale.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:12.12', '2024-05-02 14:16:12.12', NULL, NULL),
(59, 'plugin::i18n.locale.update', '{}', NULL, '{}', '[]', '2024-05-02 14:16:12.373', '2024-05-02 14:16:12.373', NULL, NULL),
(60, 'plugin::i18n.locale.delete', '{}', NULL, '{}', '[]', '2024-05-02 14:16:12.668', '2024-05-02 14:16:12.668', NULL, NULL),
(61, 'plugin::seo.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:12.968', '2024-05-02 14:16:12.968', NULL, NULL),
(62, 'plugin::users-permissions.roles.create', '{}', NULL, '{}', '[]', '2024-05-02 14:16:13.276', '2024-05-02 14:16:13.276', NULL, NULL),
(63, 'plugin::users-permissions.roles.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:13.592', '2024-05-02 14:16:13.592', NULL, NULL),
(64, 'plugin::users-permissions.roles.update', '{}', NULL, '{}', '[]', '2024-05-02 14:16:13.908', '2024-05-02 14:16:13.908', NULL, NULL),
(65, 'plugin::users-permissions.roles.delete', '{}', NULL, '{}', '[]', '2024-05-02 14:16:14.221', '2024-05-02 14:16:14.221', NULL, NULL),
(66, 'plugin::users-permissions.providers.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:14.518', '2024-05-02 14:16:14.518', NULL, NULL),
(67, 'plugin::users-permissions.providers.update', '{}', NULL, '{}', '[]', '2024-05-02 14:16:14.817', '2024-05-02 14:16:14.817', NULL, NULL),
(68, 'plugin::users-permissions.email-templates.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:15.118', '2024-05-02 14:16:15.118', NULL, NULL),
(69, 'plugin::users-permissions.email-templates.update', '{}', NULL, '{}', '[]', '2024-05-02 14:16:15.436', '2024-05-02 14:16:15.436', NULL, NULL),
(70, 'plugin::users-permissions.advanced-settings.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:15.691', '2024-05-02 14:16:15.691', NULL, NULL),
(71, 'plugin::users-permissions.advanced-settings.update', '{}', NULL, '{}', '[]', '2024-05-02 14:16:15.985', '2024-05-02 14:16:15.985', NULL, NULL),
(72, 'admin::marketplace.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:16.282', '2024-05-02 14:16:16.282', NULL, NULL),
(73, 'admin::webhooks.create', '{}', NULL, '{}', '[]', '2024-05-02 14:16:16.59', '2024-05-02 14:16:16.59', NULL, NULL),
(74, 'admin::webhooks.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:16.909', '2024-05-02 14:16:16.909', NULL, NULL),
(75, 'admin::webhooks.update', '{}', NULL, '{}', '[]', '2024-05-02 14:16:17.2', '2024-05-02 14:16:17.2', NULL, NULL),
(76, 'admin::webhooks.delete', '{}', NULL, '{}', '[]', '2024-05-02 14:16:17.501', '2024-05-02 14:16:17.501', NULL, NULL),
(77, 'admin::users.create', '{}', NULL, '{}', '[]', '2024-05-02 14:16:17.808', '2024-05-02 14:16:17.808', NULL, NULL),
(78, 'admin::users.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:18.104', '2024-05-02 14:16:18.104', NULL, NULL),
(79, 'admin::users.update', '{}', NULL, '{}', '[]', '2024-05-02 14:16:18.41', '2024-05-02 14:16:18.41', NULL, NULL),
(80, 'admin::users.delete', '{}', NULL, '{}', '[]', '2024-05-02 14:16:18.718', '2024-05-02 14:16:18.718', NULL, NULL),
(81, 'admin::roles.create', '{}', NULL, '{}', '[]', '2024-05-02 14:16:18.976', '2024-05-02 14:16:18.976', NULL, NULL),
(82, 'admin::roles.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:19.289', '2024-05-02 14:16:19.289', NULL, NULL),
(83, 'admin::roles.update', '{}', NULL, '{}', '[]', '2024-05-02 14:16:19.585', '2024-05-02 14:16:19.585', NULL, NULL),
(84, 'admin::roles.delete', '{}', NULL, '{}', '[]', '2024-05-02 14:16:19.9', '2024-05-02 14:16:19.9', NULL, NULL),
(85, 'admin::api-tokens.access', '{}', NULL, '{}', '[]', '2024-05-02 14:16:20.203', '2024-05-02 14:16:20.203', NULL, NULL),
(86, 'admin::api-tokens.create', '{}', NULL, '{}', '[]', '2024-05-02 14:16:20.454', '2024-05-02 14:16:20.454', NULL, NULL),
(87, 'admin::api-tokens.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:20.7', '2024-05-02 14:16:20.7', NULL, NULL),
(88, 'admin::api-tokens.update', '{}', NULL, '{}', '[]', '2024-05-02 14:16:20.966', '2024-05-02 14:16:20.966', NULL, NULL),
(89, 'admin::api-tokens.regenerate', '{}', NULL, '{}', '[]', '2024-05-02 14:16:21.219', '2024-05-02 14:16:21.219', NULL, NULL),
(90, 'admin::api-tokens.delete', '{}', NULL, '{}', '[]', '2024-05-02 14:16:21.511', '2024-05-02 14:16:21.511', NULL, NULL),
(91, 'admin::project-settings.update', '{}', NULL, '{}', '[]', '2024-05-02 14:16:21.804', '2024-05-02 14:16:21.804', NULL, NULL),
(92, 'admin::project-settings.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:22.104', '2024-05-02 14:16:22.104', NULL, NULL),
(93, 'admin::transfer.tokens.access', '{}', NULL, '{}', '[]', '2024-05-02 14:16:22.41', '2024-05-02 14:16:22.41', NULL, NULL),
(94, 'admin::transfer.tokens.create', '{}', NULL, '{}', '[]', '2024-05-02 14:16:22.661', '2024-05-02 14:16:22.661', NULL, NULL),
(95, 'admin::transfer.tokens.read', '{}', NULL, '{}', '[]', '2024-05-02 14:16:22.95', '2024-05-02 14:16:22.95', NULL, NULL),
(96, 'admin::transfer.tokens.update', '{}', NULL, '{}', '[]', '2024-05-02 14:16:23.208', '2024-05-02 14:16:23.208', NULL, NULL),
(97, 'admin::transfer.tokens.regenerate', '{}', NULL, '{}', '[]', '2024-05-02 14:16:23.516', '2024-05-02 14:16:23.516', NULL, NULL),
(98, 'admin::transfer.tokens.delete', '{}', NULL, '{}', '[]', '2024-05-02 14:16:23.808', '2024-05-02 14:16:23.808', NULL, NULL),
(102, 'plugin::content-manager.explorer.delete', '{}', 'api::landing-page.landing-page', '{}', '[]', '2024-05-02 15:24:00.197', '2024-05-02 15:24:00.197', NULL, NULL),
(103, 'plugin::content-manager.explorer.publish', '{}', 'api::landing-page.landing-page', '{}', '[]', '2024-05-02 15:24:00.485', '2024-05-02 15:24:00.485', NULL, NULL),
(104, 'plugin::content-manager.explorer.create', '{}', 'api::landing-page.landing-page', '{"fields": ["Title", "Slug", "Body"]}', '[]', '2024-05-02 15:25:04.461', '2024-05-02 15:25:04.461', NULL, NULL),
(105, 'plugin::content-manager.explorer.read', '{}', 'api::landing-page.landing-page', '{"fields": ["Title", "Slug", "Body"]}', '[]', '2024-05-02 15:25:04.759', '2024-05-02 15:25:04.759', NULL, NULL),
(106, 'plugin::content-manager.explorer.update', '{}', 'api::landing-page.landing-page', '{"fields": ["Title", "Slug", "Body"]}', '[]', '2024-05-02 15:25:05.074', '2024-05-02 15:25:05.074', NULL, NULL),
(110, 'plugin::content-manager.explorer.delete', '{}', 'api::health-department.health-department', '{}', '[]', '2024-05-02 16:44:44.418', '2024-05-02 16:44:44.418', NULL, NULL),
(111, 'plugin::content-manager.explorer.publish', '{}', 'api::health-department.health-department', '{}', '[]', '2024-05-02 16:44:44.742', '2024-05-02 16:44:44.742', NULL, NULL),
(115, 'plugin::content-manager.explorer.create', '{}', 'api::health-department.health-department', '{"fields": ["Title", "Street", "City", "Contact", "Phone", "Fax", "ZIPCode"]}', '[]', '2024-05-02 16:56:16.335', '2024-05-02 16:56:16.335', NULL, NULL),
(116, 'plugin::content-manager.explorer.read', '{}', 'api::health-department.health-department', '{"fields": ["Title", "Street", "City", "Contact", "Phone", "Fax", "ZIPCode"]}', '[]', '2024-05-02 16:56:16.619', '2024-05-02 16:56:16.619', NULL, NULL),
(117, 'plugin::content-manager.explorer.update', '{}', 'api::health-department.health-department', '{"fields": ["Title", "Street", "City", "Contact", "Phone", "Fax", "ZIPCode"]}', '[]', '2024-05-02 16:56:16.894', '2024-05-02 16:56:16.894', NULL, NULL),
(118, 'plugin::content-manager.explorer.create', '{}', 'api::article.article', '{"fields": ["Title", "Slug", "Body"]}', '[]', '2024-05-02 17:46:39.343', '2024-05-02 17:46:39.343', NULL, NULL),
(119, 'plugin::content-manager.explorer.read', '{}', 'api::article.article', '{"fields": ["Title", "Slug", "Body"]}', '[]', '2024-05-02 17:46:39.647', '2024-05-02 17:46:39.647', NULL, NULL),
(120, 'plugin::content-manager.explorer.update', '{}', 'api::article.article', '{"fields": ["Title", "Slug", "Body"]}', '[]', '2024-05-02 17:46:39.932', '2024-05-02 17:46:39.932', NULL, NULL);

INSERT INTO "public"."admin_permissions_role_links" ("id", "permission_id", "role_id", "permission_order") VALUES
(1, 1, 2, 1),
(2, 2, 2, 2),
(3, 3, 2, 3),
(4, 4, 2, 4),
(5, 5, 2, 5),
(6, 6, 2, 6),
(7, 7, 2, 7),
(8, 8, 2, 8),
(9, 9, 2, 9),
(10, 10, 2, 10),
(11, 11, 2, 11),
(12, 12, 2, 12),
(13, 13, 2, 13),
(14, 14, 2, 14),
(15, 15, 2, 15),
(16, 16, 2, 16),
(17, 17, 3, 1),
(18, 18, 3, 2),
(19, 19, 3, 3),
(20, 20, 3, 4),
(21, 21, 3, 5),
(22, 22, 3, 6),
(23, 23, 3, 7),
(24, 24, 3, 8),
(25, 25, 3, 9),
(26, 26, 3, 10),
(27, 27, 3, 11),
(28, 28, 3, 12),
(29, 29, 3, 13),
(30, 30, 3, 14),
(32, 32, 1, 2),
(33, 33, 1, 3),
(35, 35, 1, 5),
(36, 36, 1, 6),
(38, 38, 1, 8),
(39, 39, 1, 9),
(40, 40, 1, 10),
(41, 41, 1, 11),
(42, 42, 1, 12),
(43, 43, 1, 13),
(44, 44, 1, 14),
(45, 45, 1, 15),
(46, 46, 1, 16),
(47, 47, 1, 17),
(48, 48, 1, 18),
(49, 49, 1, 19),
(50, 50, 1, 20),
(51, 51, 1, 21),
(52, 52, 1, 22),
(53, 53, 1, 23),
(54, 54, 1, 24),
(55, 55, 1, 25),
(56, 56, 1, 26),
(57, 57, 1, 27),
(58, 58, 1, 28),
(59, 59, 1, 29),
(60, 60, 1, 30),
(61, 61, 1, 31),
(62, 62, 1, 32),
(63, 63, 1, 33),
(64, 64, 1, 34),
(65, 65, 1, 35),
(66, 66, 1, 36),
(67, 67, 1, 37),
(68, 68, 1, 38),
(69, 69, 1, 39),
(70, 70, 1, 40),
(71, 71, 1, 41),
(72, 72, 1, 42),
(73, 73, 1, 43),
(74, 74, 1, 44),
(75, 75, 1, 45),
(76, 76, 1, 46),
(77, 77, 1, 47),
(78, 78, 1, 48),
(79, 79, 1, 49),
(80, 80, 1, 50),
(81, 81, 1, 51),
(82, 82, 1, 52),
(83, 83, 1, 53),
(84, 84, 1, 54),
(85, 85, 1, 55),
(86, 86, 1, 56),
(87, 87, 1, 57),
(88, 88, 1, 58),
(89, 89, 1, 59),
(90, 90, 1, 60),
(91, 91, 1, 61),
(92, 92, 1, 62),
(93, 93, 1, 63),
(94, 94, 1, 64),
(95, 95, 1, 65),
(96, 96, 1, 66),
(97, 97, 1, 67),
(98, 98, 1, 68),
(102, 102, 1, 72),
(103, 103, 1, 73),
(104, 104, 1, 74),
(105, 105, 1, 75),
(106, 106, 1, 76),
(110, 110, 1, 80),
(111, 111, 1, 81),
(115, 115, 1, 82),
(116, 116, 1, 83),
(117, 117, 1, 84),
(118, 118, 1, 85),
(119, 119, 1, 86),
(120, 120, 1, 87);

INSERT INTO "public"."admin_roles" ("id", "name", "code", "description", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, 'Super Admin', 'strapi-super-admin', 'Super Admins can access and manage all features and settings.', '2024-05-02 14:15:55.113', '2024-05-02 14:15:55.113', NULL, NULL),
(2, 'Editor', 'strapi-editor', 'Editors can manage and publish contents including those of other users.', '2024-05-02 14:15:55.357', '2024-05-02 14:15:55.357', NULL, NULL),
(3, 'Author', 'strapi-author', 'Authors can manage the content they have created.', '2024-05-02 14:15:55.582', '2024-05-02 14:15:55.582', NULL, NULL);

INSERT INTO "public"."admin_users" ("id", "firstname", "lastname", "username", "email", "password", "reset_password_token", "registration_token", "is_active", "blocked", "prefered_language", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, 'Hurdi', 'Gurdi', NULL, 'hurdi@gurdi.de', '$2a$10$F04/xpX29JURMlCsmSH1COsuXO8TPLd0oLIB6TfNWfgC70LgB0YTm', NULL, NULL, 't', 'f', NULL, '2024-05-02 14:16:48.655', '2024-05-02 14:16:48.655', NULL, NULL);

INSERT INTO "public"."admin_users_roles_links" ("id", "user_id", "role_id", "role_order", "user_order") VALUES
(1, 1, 1, 1, 1);

INSERT INTO "public"."articles" ("id", "title", "slug", "created_at", "updated_at", "published_at", "created_by_id", "updated_by_id", "body") VALUES
(2, 'My Article', 'my-article', '2024-05-02 17:55:35.205', '2024-05-02 17:55:35.205', NULL, 1, 1, '[{"type": "heading", "level": 2, "children": [{"text": "Hello World", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "", "type": "text"}]}, {"type": "paragraph", "children": [{"bold": true, "text": "bold text", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "", "type": "text"}, {"url": "/#", "type": "link", "children": [{"text": "Link", "type": "text"}]}, {"text": "", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "just plan text", "type": "text"}]}]');

INSERT INTO "public"."components_blocks_ctas" ("id", "label", "href", "type") VALUES
(1, 'Zu den Services und Themen', '#services-und-themen', 'Primary Button'),
(2, 'Welches Amt ist zuständig', '/#', 'Link'),
(3, 'Alle bayrischen Gesundheitsämter', '/#', 'Link');

INSERT INTO "public"."components_landing_page_button_cards" ("id", "label", "url") VALUES
(1, 'Infektionsschutz', '/infektionsschutz'),
(2, 'Medizinal Aufsicht und Begutachtung', '/medizinalaufsicht-begutachtung'),
(3, 'Hygiene & Arbeitssicherheit', '/hygiene-und-arbeitssicherheit'),
(4, 'Lebensmittel', '/lebensmittel'),
(5, 'Kinder & Jugend', '/kinder-und-jugend'),
(6, 'Gesundheitsberatung', '/gesundheitsberatung');

INSERT INTO "public"."components_landing_page_button_teasers" ("id", "headline", "subline") VALUES
(1, 'Weitere Aufgabengebiete der bayrischen Gesundheitsämter', 'Wir helfen bei vielen verschiedenen Themen rund um');

INSERT INTO "public"."components_landing_page_button_teasers_components" ("id", "entity_id", "component_id", "component_type", "field", "order") VALUES
(1, 1, 1, 'landing-page.button-cards', 'ButtonCard', 1),
(2, 1, 1, 'blocks.button-cards', 'ButtonCard', 1),
(5, 1, 2, 'blocks.button-cards', 'ButtonCard', 2),
(6, 1, 5, 'blocks.button-cards', 'ButtonCard', 3),
(7, 1, 6, 'blocks.button-cards', 'ButtonCard', 4),
(8, 1, 3, 'blocks.button-cards', 'ButtonCard', 5),
(9, 1, 4, 'blocks.button-cards', 'ButtonCard', 6);

INSERT INTO "public"."components_landing_page_content_cards" ("id", "headline", "copy") VALUES
(1, 'Amtsärztliche Begutachtung', 'Das Gesundheitsamt erstellt im Auftrag amtsärztliche Gutachten, Zeugnisse und Bescheinigungen'),
(2, 'Datenübertragung Medizinal Aufsicht', 'Hier können sie dem entsprechenden Gesundheitsamt mitteilen, wenn sie ihre medizinische oder pflegerische Tätigkeit beginnen, beenden oder Änderungen vornehmen müssen. ');

INSERT INTO "public"."components_landing_page_ga_searches" ("id", "headline", "copy") VALUES
(1, 'Ihr Gesundheitsamt vor Ort', 'Wählen sie Ihr Gesundheitsamt, um die individuellen Leistungen zu sehen');

INSERT INTO "public"."components_landing_page_ga_searches_components" ("id", "entity_id", "component_id", "component_type", "field", "order") VALUES
(1, 1, 2, 'blocks.cta', 'Ctas', 1),
(2, 1, 3, 'blocks.cta', 'Ctas', 2);

INSERT INTO "public"."components_landing_page_stages" ("id", "headline", "subline") VALUES
(1, 'Mit einem Klick so nah', 'Ihr direkter Zugang zu den digitalen Services der bayerischen Gesundheitsämter');

INSERT INTO "public"."components_landing_page_stages_components" ("id", "entity_id", "component_id", "component_type", "field", "order") VALUES
(1, 1, 1, 'blocks.cta', 'Ctas', 1);

INSERT INTO "public"."components_landing_page_teasers" ("id", "headline") VALUES
(1, 'Unsere Services');

INSERT INTO "public"."components_landing_page_teasers_components" ("id", "entity_id", "component_id", "component_type", "field", "order") VALUES
(1, 1, 1, 'landing-page.content-card', 'ContentCard', 1),
(2, 1, 2, 'landing-page.content-card', 'ContentCard', 4),
(5, 1, 1, 'blocks.content-card', 'ContentCard', 1),
(6, 1, 2, 'blocks.content-card', 'ContentCard', 2);

INSERT INTO "public"."files" ("id", "name", "alternative_text", "caption", "width", "height", "formats", "hash", "ext", "mime", "size", "url", "preview_url", "provider", "provider_metadata", "folder_path", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, '569eda10121272387c8b68f7f40ed786', NULL, NULL, 3864, 2576, '{"large": {"ext": ".jpeg", "url": "/uploads/large_569eda10121272387c8b68f7f40ed786_7801c69db2.jpeg", "hash": "large_569eda10121272387c8b68f7f40ed786_7801c69db2", "mime": "image/jpeg", "name": "large_569eda10121272387c8b68f7f40ed786", "path": null, "size": 70.21, "width": 1000, "height": 667, "sizeInBytes": 70206}, "small": {"ext": ".jpeg", "url": "/uploads/small_569eda10121272387c8b68f7f40ed786_7801c69db2.jpeg", "hash": "small_569eda10121272387c8b68f7f40ed786_7801c69db2", "mime": "image/jpeg", "name": "small_569eda10121272387c8b68f7f40ed786", "path": null, "size": 23.63, "width": 500, "height": 333, "sizeInBytes": 23630}, "medium": {"ext": ".jpeg", "url": "/uploads/medium_569eda10121272387c8b68f7f40ed786_7801c69db2.jpeg", "hash": "medium_569eda10121272387c8b68f7f40ed786_7801c69db2", "mime": "image/jpeg", "name": "medium_569eda10121272387c8b68f7f40ed786", "path": null, "size": 43.98, "width": 750, "height": 500, "sizeInBytes": 43982}, "thumbnail": {"ext": ".jpeg", "url": "/uploads/thumbnail_569eda10121272387c8b68f7f40ed786_7801c69db2.jpeg", "hash": "thumbnail_569eda10121272387c8b68f7f40ed786_7801c69db2", "mime": "image/jpeg", "name": "thumbnail_569eda10121272387c8b68f7f40ed786", "path": null, "size": 7.78, "width": 234, "height": 156, "sizeInBytes": 7781}}', '569eda10121272387c8b68f7f40ed786_7801c69db2', '.jpeg', 'image/jpeg', 756.20, '/uploads/569eda10121272387c8b68f7f40ed786_7801c69db2.jpeg', NULL, 'local', NULL, '/', '2024-05-02 16:17:02.823', '2024-05-02 16:24:01.046', 1, 1);

INSERT INTO "public"."files_related_morphs" ("id", "file_id", "related_id", "related_type", "field", "order") VALUES
(4, 1, 1, 'landing-page.stage', 'BackgroundImage', 1);

INSERT INTO "public"."health_departments" ("id", "title", "street", "city", "contact", "created_at", "updated_at", "published_at", "created_by_id", "updated_by_id", "phone", "fax", "zip_code") VALUES
(1, 'Gesundheitsamt Erlangen Höchstadt', 'Nägelbachstraße1', 'Erlangen', 'gesundheitsamt@erlangen-hoechstadt.de', '2024-05-02 16:54:03.988', '2024-05-02 16:57:45.544', NULL, 1, 1, '09131 803 2200', '09131 803 492200', '91052');

INSERT INTO "public"."i18n_locale" ("id", "name", "code", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, 'English (en)', 'en', '2024-05-02 14:15:52.331', '2024-05-02 14:15:52.331', NULL, NULL);

INSERT INTO "public"."landing_pages" ("id", "title", "slug", "created_at", "updated_at", "published_at", "created_by_id", "updated_by_id") VALUES
(1, 'Homepage', 'homepage', '2024-05-02 15:29:06.651', '2024-05-02 16:52:07.988', NULL, 1, 1);

INSERT INTO "public"."landing_pages_components" ("id", "entity_id", "component_id", "component_type", "field", "order") VALUES
(15, 1, 1, 'landing-page.stage', 'Body', 1),
(16, 1, 1, 'landing-page.teaser', 'Body', 2),
(17, 1, 1, 'landing-page.button-teaser', 'Body', 3),
(18, 1, 1, 'landing-page.ga-search', 'Body', 4);

INSERT INTO "public"."strapi_core_store_settings" ("id", "key", "value", "type", "environment", "tag") VALUES
(1, 'strapi_content_types_schema', '{"admin::permission":{"collectionName":"admin_permissions","info":{"name":"Permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"actionParameters":{"type":"json","configurable":false,"required":false,"default":{}},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::role"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"admin_permissions","info":{"name":"Permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"actionParameters":{"type":"json","configurable":false,"required":false,"default":{}},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::role"}},"kind":"collectionType"},"modelType":"contentType","modelName":"permission","connection":"default","uid":"admin::permission","plugin":"admin","globalId":"AdminPermission"},"admin::user":{"collectionName":"admin_users","info":{"name":"User","description":"","singularName":"user","pluralName":"users","displayName":"User"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"registrationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"configurable":false,"private":true,"type":"relation","relation":"manyToMany","inversedBy":"users","target":"admin::role","collectionName":"strapi_users_roles"},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"config":{"attributes":{"resetPasswordToken":{"hidden":true},"registrationToken":{"hidden":true}}},"kind":"collectionType","__schema__":{"collectionName":"admin_users","info":{"name":"User","description":"","singularName":"user","pluralName":"users","displayName":"User"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"registrationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"configurable":false,"private":true,"type":"relation","relation":"manyToMany","inversedBy":"users","target":"admin::role","collectionName":"strapi_users_roles"},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false,"searchable":false}},"kind":"collectionType"},"modelType":"contentType","modelName":"user","connection":"default","uid":"admin::user","plugin":"admin","globalId":"AdminUser"},"admin::role":{"collectionName":"admin_roles","info":{"name":"Role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"type":"relation","relation":"manyToMany","mappedBy":"roles","target":"admin::user"},"permissions":{"configurable":false,"type":"relation","relation":"oneToMany","mappedBy":"role","target":"admin::permission"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"admin_roles","info":{"name":"Role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"type":"relation","relation":"manyToMany","mappedBy":"roles","target":"admin::user"},"permissions":{"configurable":false,"type":"relation","relation":"oneToMany","mappedBy":"role","target":"admin::permission"}},"kind":"collectionType"},"modelType":"contentType","modelName":"role","connection":"default","uid":"admin::role","plugin":"admin","globalId":"AdminRole"},"admin::api-token":{"collectionName":"strapi_api_tokens","info":{"name":"Api Token","singularName":"api-token","pluralName":"api-tokens","displayName":"Api Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"type":{"type":"enumeration","enum":["read-only","full-access","custom"],"configurable":false,"required":true,"default":"read-only"},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true,"searchable":false},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::api-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"strapi_api_tokens","info":{"name":"Api Token","singularName":"api-token","pluralName":"api-tokens","displayName":"Api Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"type":{"type":"enumeration","enum":["read-only","full-access","custom"],"configurable":false,"required":true,"default":"read-only"},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true,"searchable":false},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::api-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false}},"kind":"collectionType"},"modelType":"contentType","modelName":"api-token","connection":"default","uid":"admin::api-token","plugin":"admin","globalId":"AdminApiToken"},"admin::api-token-permission":{"collectionName":"strapi_api_token_permissions","info":{"name":"API Token Permission","description":"","singularName":"api-token-permission","pluralName":"api-token-permissions","displayName":"API Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::api-token"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"strapi_api_token_permissions","info":{"name":"API Token Permission","description":"","singularName":"api-token-permission","pluralName":"api-token-permissions","displayName":"API Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::api-token"}},"kind":"collectionType"},"modelType":"contentType","modelName":"api-token-permission","connection":"default","uid":"admin::api-token-permission","plugin":"admin","globalId":"AdminApiTokenPermission"},"admin::transfer-token":{"collectionName":"strapi_transfer_tokens","info":{"name":"Transfer Token","singularName":"transfer-token","pluralName":"transfer-tokens","displayName":"Transfer Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::transfer-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"strapi_transfer_tokens","info":{"name":"Transfer Token","singularName":"transfer-token","pluralName":"transfer-tokens","displayName":"Transfer Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::transfer-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false}},"kind":"collectionType"},"modelType":"contentType","modelName":"transfer-token","connection":"default","uid":"admin::transfer-token","plugin":"admin","globalId":"AdminTransferToken"},"admin::transfer-token-permission":{"collectionName":"strapi_transfer_token_permissions","info":{"name":"Transfer Token Permission","description":"","singularName":"transfer-token-permission","pluralName":"transfer-token-permissions","displayName":"Transfer Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::transfer-token"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"strapi_transfer_token_permissions","info":{"name":"Transfer Token Permission","description":"","singularName":"transfer-token-permission","pluralName":"transfer-token-permissions","displayName":"Transfer Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::transfer-token"}},"kind":"collectionType"},"modelType":"contentType","modelName":"transfer-token-permission","connection":"default","uid":"admin::transfer-token-permission","plugin":"admin","globalId":"AdminTransferTokenPermission"},"plugin::upload.file":{"collectionName":"files","info":{"singularName":"file","pluralName":"files","displayName":"File","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"string","configurable":false},"caption":{"type":"string","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"string","configurable":false,"required":true},"previewUrl":{"type":"string","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"type":"relation","relation":"morphToMany","configurable":false},"folder":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"files","private":true},"folderPath":{"type":"string","min":1,"required":true,"private":true,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"indexes":[{"name":"upload_files_folder_path_index","columns":["folder_path"],"type":null},{"name":"upload_files_created_at_index","columns":["created_at"],"type":null},{"name":"upload_files_updated_at_index","columns":["updated_at"],"type":null},{"name":"upload_files_name_index","columns":["name"],"type":null},{"name":"upload_files_size_index","columns":["size"],"type":null},{"name":"upload_files_ext_index","columns":["ext"],"type":null}],"kind":"collectionType","__schema__":{"collectionName":"files","info":{"singularName":"file","pluralName":"files","displayName":"File","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"string","configurable":false},"caption":{"type":"string","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"string","configurable":false,"required":true},"previewUrl":{"type":"string","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"type":"relation","relation":"morphToMany","configurable":false},"folder":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"files","private":true},"folderPath":{"type":"string","min":1,"required":true,"private":true,"searchable":false}},"kind":"collectionType"},"modelType":"contentType","modelName":"file","connection":"default","uid":"plugin::upload.file","plugin":"upload","globalId":"UploadFile"},"plugin::upload.folder":{"collectionName":"upload_folders","info":{"singularName":"folder","pluralName":"folders","displayName":"Folder"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"required":true},"pathId":{"type":"integer","unique":true,"required":true},"parent":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","mappedBy":"parent"},"files":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","mappedBy":"folder"},"path":{"type":"string","min":1,"required":true},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"indexes":[{"name":"upload_folders_path_id_index","columns":["path_id"],"type":"unique"},{"name":"upload_folders_path_index","columns":["path"],"type":"unique"}],"kind":"collectionType","__schema__":{"collectionName":"upload_folders","info":{"singularName":"folder","pluralName":"folders","displayName":"Folder"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"required":true},"pathId":{"type":"integer","unique":true,"required":true},"parent":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","mappedBy":"parent"},"files":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","mappedBy":"folder"},"path":{"type":"string","min":1,"required":true}},"kind":"collectionType"},"modelType":"contentType","modelName":"folder","connection":"default","uid":"plugin::upload.folder","plugin":"upload","globalId":"UploadFolder"},"plugin::content-releases.release":{"collectionName":"strapi_releases","info":{"singularName":"release","pluralName":"releases","displayName":"Release"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true},"releasedAt":{"type":"datetime"},"scheduledAt":{"type":"datetime"},"timezone":{"type":"string"},"status":{"type":"enumeration","enum":["ready","blocked","failed","done","empty"],"required":true},"actions":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","mappedBy":"release"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"strapi_releases","info":{"singularName":"release","pluralName":"releases","displayName":"Release"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true},"releasedAt":{"type":"datetime"},"scheduledAt":{"type":"datetime"},"timezone":{"type":"string"},"status":{"type":"enumeration","enum":["ready","blocked","failed","done","empty"],"required":true},"actions":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","mappedBy":"release"}},"kind":"collectionType"},"modelType":"contentType","modelName":"release","connection":"default","uid":"plugin::content-releases.release","plugin":"content-releases","globalId":"ContentReleasesRelease"},"plugin::content-releases.release-action":{"collectionName":"strapi_release_actions","info":{"singularName":"release-action","pluralName":"release-actions","displayName":"Release Action"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"type":{"type":"enumeration","enum":["publish","unpublish"],"required":true},"entry":{"type":"relation","relation":"morphToOne","configurable":false},"contentType":{"type":"string","required":true},"locale":{"type":"string"},"release":{"type":"relation","relation":"manyToOne","target":"plugin::content-releases.release","inversedBy":"actions"},"isEntryValid":{"type":"boolean"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"strapi_release_actions","info":{"singularName":"release-action","pluralName":"release-actions","displayName":"Release Action"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"type":{"type":"enumeration","enum":["publish","unpublish"],"required":true},"entry":{"type":"relation","relation":"morphToOne","configurable":false},"contentType":{"type":"string","required":true},"locale":{"type":"string"},"release":{"type":"relation","relation":"manyToOne","target":"plugin::content-releases.release","inversedBy":"actions"},"isEntryValid":{"type":"boolean"}},"kind":"collectionType"},"modelType":"contentType","modelName":"release-action","connection":"default","uid":"plugin::content-releases.release-action","plugin":"content-releases","globalId":"ContentReleasesReleaseAction"},"plugin::i18n.locale":{"info":{"singularName":"locale","pluralName":"locales","collectionName":"locales","displayName":"Locale","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"info":{"singularName":"locale","pluralName":"locales","collectionName":"locales","displayName":"Locale","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false}},"kind":"collectionType"},"modelType":"contentType","modelName":"locale","connection":"default","uid":"plugin::i18n.locale","plugin":"i18n","collectionName":"i18n_locale","globalId":"I18NLocale"},"plugin::users-permissions.permission":{"collectionName":"up_permissions","info":{"name":"permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"permissions","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"up_permissions","info":{"name":"permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"permissions","configurable":false}},"kind":"collectionType"},"modelType":"contentType","modelName":"permission","connection":"default","uid":"plugin::users-permissions.permission","plugin":"users-permissions","globalId":"UsersPermissionsPermission"},"plugin::users-permissions.role":{"collectionName":"up_roles","info":{"name":"role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","mappedBy":"role","configurable":false},"users":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","mappedBy":"role","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"kind":"collectionType","__schema__":{"collectionName":"up_roles","info":{"name":"role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","mappedBy":"role","configurable":false},"users":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","mappedBy":"role","configurable":false}},"kind":"collectionType"},"modelType":"contentType","modelName":"role","connection":"default","uid":"plugin::users-permissions.role","plugin":"users-permissions","globalId":"UsersPermissionsRole"},"plugin::users-permissions.user":{"collectionName":"up_users","info":{"name":"user","description":"","singularName":"user","pluralName":"users","displayName":"User"},"options":{"draftAndPublish":false,"timestamps":true},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"users","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"config":{"attributes":{"resetPasswordToken":{"hidden":true},"confirmationToken":{"hidden":true},"provider":{"hidden":true}}},"kind":"collectionType","__schema__":{"collectionName":"up_users","info":{"name":"user","description":"","singularName":"user","pluralName":"users","displayName":"User"},"options":{"draftAndPublish":false,"timestamps":true},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"users","configurable":false}},"kind":"collectionType"},"modelType":"contentType","modelName":"user","connection":"default","uid":"plugin::users-permissions.user","plugin":"users-permissions","globalId":"UsersPermissionsUser"},"api::article.article":{"kind":"collectionType","collectionName":"articles","info":{"singularName":"article","pluralName":"articles","displayName":"Article","description":""},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"Title":{"type":"string"},"Slug":{"type":"uid","targetField":"Title"},"Body":{"type":"blocks"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"__schema__":{"collectionName":"articles","info":{"singularName":"article","pluralName":"articles","displayName":"Article","description":""},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"Title":{"type":"string"},"Slug":{"type":"uid","targetField":"Title"},"Body":{"type":"blocks"}},"kind":"collectionType"},"modelType":"contentType","modelName":"article","connection":"default","uid":"api::article.article","apiName":"article","globalId":"Article","actions":{},"lifecycles":{}},"api::global-article.global-article":{"kind":"collectionType","collectionName":"global_articles","info":{"singularName":"global-article","pluralName":"global-articles","displayName":"Global Article"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"Title":{"type":"string"},"Slug":{"type":"uid","targetField":"Title"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"__schema__":{"collectionName":"global_articles","info":{"singularName":"global-article","pluralName":"global-articles","displayName":"Global Article"},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"Title":{"type":"string"},"Slug":{"type":"uid","targetField":"Title"}},"kind":"collectionType"},"modelType":"contentType","modelName":"global-article","connection":"default","uid":"api::global-article.global-article","apiName":"global-article","globalId":"GlobalArticle","actions":{},"lifecycles":{}},"api::health-department.health-department":{"kind":"collectionType","collectionName":"health_departments","info":{"singularName":"health-department","pluralName":"health-departments","displayName":"Health Department","description":""},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"Title":{"type":"string"},"Street":{"type":"string"},"City":{"type":"string"},"Contact":{"type":"email"},"Phone":{"type":"string"},"Fax":{"type":"string"},"ZIPCode":{"type":"string"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"__schema__":{"collectionName":"health_departments","info":{"singularName":"health-department","pluralName":"health-departments","displayName":"Health Department","description":""},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"Title":{"type":"string"},"Street":{"type":"string"},"City":{"type":"string"},"Contact":{"type":"email"},"Phone":{"type":"string"},"Fax":{"type":"string"},"ZIPCode":{"type":"string"}},"kind":"collectionType"},"modelType":"contentType","modelName":"health-department","connection":"default","uid":"api::health-department.health-department","apiName":"health-department","globalId":"HealthDepartment","actions":{},"lifecycles":{}},"api::landing-page.landing-page":{"kind":"collectionType","collectionName":"landing_pages","info":{"singularName":"landing-page","pluralName":"landing-pages","displayName":"Landing Page","description":""},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"Title":{"type":"string"},"Slug":{"type":"uid","targetField":"Title"},"Body":{"type":"dynamiczone","components":["landing-page.teaser","landing-page.button-teaser","landing-page.stage","landing-page.ga-search"]},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":false},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true}},"__schema__":{"collectionName":"landing_pages","info":{"singularName":"landing-page","pluralName":"landing-pages","displayName":"Landing Page","description":""},"options":{"draftAndPublish":true},"pluginOptions":{},"attributes":{"Title":{"type":"string"},"Slug":{"type":"uid","targetField":"Title"},"Body":{"type":"dynamiczone","components":["landing-page.teaser","landing-page.button-teaser","landing-page.stage","landing-page.ga-search"]}},"kind":"collectionType"},"modelType":"contentType","modelName":"landing-page","connection":"default","uid":"api::landing-page.landing-page","apiName":"landing-page","globalId":"LandingPage","actions":{},"lifecycles":{}}}', 'object', NULL, NULL),
(2, 'plugin_content_manager_configuration_content_types::admin::api-token', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"accessKey":{"edit":{"label":"accessKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessKey","searchable":true,"sortable":true}},"lastUsedAt":{"edit":{"label":"lastUsedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastUsedAt","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"lifespan":{"edit":{"label":"lifespan","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lifespan","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6},{"name":"accessKey","size":6}],[{"name":"lastUsedAt","size":6},{"name":"permissions","size":6}],[{"name":"expiresAt","size":6},{"name":"lifespan","size":4}]]},"uid":"admin::api-token"}', 'object', NULL, NULL),
(3, 'plugin_content_manager_configuration_content_types::admin::user', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"firstname","defaultSortBy":"firstname","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"firstname":{"edit":{"label":"firstname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"firstname","searchable":true,"sortable":true}},"lastname":{"edit":{"label":"lastname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastname","searchable":true,"sortable":true}},"username":{"edit":{"label":"username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"username","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"password":{"edit":{"label":"password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"resetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"resetPasswordToken","searchable":true,"sortable":true}},"registrationToken":{"edit":{"label":"registrationToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"registrationToken","searchable":true,"sortable":true}},"isActive":{"edit":{"label":"isActive","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isActive","searchable":true,"sortable":true}},"roles":{"edit":{"label":"roles","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"roles","searchable":false,"sortable":false}},"blocked":{"edit":{"label":"blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"blocked","searchable":true,"sortable":true}},"preferedLanguage":{"edit":{"label":"preferedLanguage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"preferedLanguage","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","firstname","lastname","username"],"edit":[[{"name":"firstname","size":6},{"name":"lastname","size":6}],[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"isActive","size":4}],[{"name":"roles","size":6},{"name":"blocked","size":4}],[{"name":"preferedLanguage","size":6}]]},"uid":"admin::user"}', 'object', NULL, NULL),
(4, 'plugin_content_manager_configuration_content_types::admin::permission', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"actionParameters":{"edit":{"label":"actionParameters","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"actionParameters","searchable":false,"sortable":false}},"subject":{"edit":{"label":"subject","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"subject","searchable":true,"sortable":true}},"properties":{"edit":{"label":"properties","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"properties","searchable":false,"sortable":false}},"conditions":{"edit":{"label":"conditions","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"conditions","searchable":false,"sortable":false}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","subject","role"],"edit":[[{"name":"action","size":6}],[{"name":"actionParameters","size":12}],[{"name":"subject","size":6}],[{"name":"properties","size":12}],[{"name":"conditions","size":12}],[{"name":"role","size":6}]]},"uid":"admin::permission"}', 'object', NULL, NULL),
(5, 'plugin_content_manager_configuration_content_types::admin::api-token-permission', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"token":{"edit":{"label":"token","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"token","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","token","createdAt"],"edit":[[{"name":"action","size":6},{"name":"token","size":6}]]},"uid":"admin::api-token-permission"}', 'object', NULL, NULL),
(6, 'plugin_content_manager_configuration_content_types::admin::role', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"code":{"edit":{"label":"code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"code","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"users":{"edit":{"label":"users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"users","searchable":false,"sortable":false}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","description"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}],[{"name":"description","size":6},{"name":"users","size":6}],[{"name":"permissions","size":6}]]},"uid":"admin::role"}', 'object', NULL, NULL),
(7, 'plugin_content_manager_configuration_content_types::admin::transfer-token', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"accessKey":{"edit":{"label":"accessKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessKey","searchable":true,"sortable":true}},"lastUsedAt":{"edit":{"label":"lastUsedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastUsedAt","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"lifespan":{"edit":{"label":"lifespan","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lifespan","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","accessKey"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"accessKey","size":6},{"name":"lastUsedAt","size":6}],[{"name":"permissions","size":6},{"name":"expiresAt","size":6}],[{"name":"lifespan","size":4}]]},"uid":"admin::transfer-token"}', 'object', NULL, NULL),
(8, 'plugin_content_manager_configuration_content_types::admin::transfer-token-permission', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"token":{"edit":{"label":"token","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"token","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","token","createdAt"],"edit":[[{"name":"action","size":6},{"name":"token","size":6}]]},"uid":"admin::transfer-token-permission"}', 'object', NULL, NULL),
(9, 'plugin_content_manager_configuration_content_types::plugin::content-releases.release-action', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"contentType","defaultSortBy":"contentType","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"contentType":{"edit":{"label":"contentType","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contentType","searchable":true,"sortable":true}},"locale":{"edit":{"label":"locale","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"locale","searchable":true,"sortable":true}},"release":{"edit":{"label":"release","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"release","searchable":true,"sortable":true}},"isEntryValid":{"edit":{"label":"isEntryValid","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isEntryValid","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","type","contentType","locale"],"edit":[[{"name":"type","size":6},{"name":"contentType","size":6}],[{"name":"locale","size":6},{"name":"release","size":6}],[{"name":"isEntryValid","size":4}]]},"uid":"plugin::content-releases.release-action"}', 'object', NULL, NULL),
(10, 'plugin_content_manager_configuration_content_types::api::global-article.global-article', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"Title","defaultSortBy":"Title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"Title":{"edit":{"label":"Title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Title","searchable":true,"sortable":true}},"Slug":{"edit":{"label":"Slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Slug","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","Title","Slug","createdAt"],"edit":[[{"name":"Title","size":6},{"name":"Slug","size":6}]]},"uid":"api::global-article.global-article"}', 'object', NULL, NULL),
(11, 'plugin_content_manager_configuration_content_types::plugin::upload.file', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"alternativeText":{"edit":{"label":"alternativeText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"alternativeText","searchable":true,"sortable":true}},"caption":{"edit":{"label":"caption","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"caption","searchable":true,"sortable":true}},"width":{"edit":{"label":"width","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"width","searchable":true,"sortable":true}},"height":{"edit":{"label":"height","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"height","searchable":true,"sortable":true}},"formats":{"edit":{"label":"formats","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"formats","searchable":false,"sortable":false}},"hash":{"edit":{"label":"hash","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"hash","searchable":true,"sortable":true}},"ext":{"edit":{"label":"ext","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ext","searchable":true,"sortable":true}},"mime":{"edit":{"label":"mime","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"mime","searchable":true,"sortable":true}},"size":{"edit":{"label":"size","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"size","searchable":true,"sortable":true}},"url":{"edit":{"label":"url","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"url","searchable":true,"sortable":true}},"previewUrl":{"edit":{"label":"previewUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"previewUrl","searchable":true,"sortable":true}},"provider":{"edit":{"label":"provider","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"provider","searchable":true,"sortable":true}},"provider_metadata":{"edit":{"label":"provider_metadata","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"provider_metadata","searchable":false,"sortable":false}},"folder":{"edit":{"label":"folder","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"folder","searchable":true,"sortable":true}},"folderPath":{"edit":{"label":"folderPath","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"folderPath","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","alternativeText","caption"],"edit":[[{"name":"name","size":6},{"name":"alternativeText","size":6}],[{"name":"caption","size":6},{"name":"width","size":4}],[{"name":"height","size":4}],[{"name":"formats","size":12}],[{"name":"hash","size":6},{"name":"ext","size":6}],[{"name":"mime","size":6},{"name":"size","size":4}],[{"name":"url","size":6},{"name":"previewUrl","size":6}],[{"name":"provider","size":6}],[{"name":"provider_metadata","size":12}],[{"name":"folder","size":6},{"name":"folderPath","size":6}]]},"uid":"plugin::upload.file"}', 'object', NULL, NULL),
(12, 'plugin_content_manager_configuration_content_types::api::article.article', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"Title","defaultSortBy":"Title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"Title":{"edit":{"label":"Title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Title","searchable":true,"sortable":true}},"Slug":{"edit":{"label":"Slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Slug","searchable":true,"sortable":true}},"Body":{"edit":{"label":"Body","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Body","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","Title","Slug","createdAt"],"edit":[[{"name":"Title","size":6},{"name":"Slug","size":6}],[{"name":"Body","size":12}]]},"uid":"api::article.article"}', 'object', NULL, NULL),
(13, 'plugin_content_manager_configuration_content_types::plugin::content-releases.release', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"releasedAt":{"edit":{"label":"releasedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"releasedAt","searchable":true,"sortable":true}},"scheduledAt":{"edit":{"label":"scheduledAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"scheduledAt","searchable":true,"sortable":true}},"timezone":{"edit":{"label":"timezone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"timezone","searchable":true,"sortable":true}},"status":{"edit":{"label":"status","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"status","searchable":true,"sortable":true}},"actions":{"edit":{"label":"actions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"contentType"},"list":{"label":"actions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","releasedAt","scheduledAt"],"edit":[[{"name":"name","size":6},{"name":"releasedAt","size":6}],[{"name":"scheduledAt","size":6},{"name":"timezone","size":6}],[{"name":"status","size":6},{"name":"actions","size":6}]]},"uid":"plugin::content-releases.release"}', 'object', NULL, NULL),
(14, 'plugin_content_manager_configuration_content_types::plugin::upload.folder', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"pathId":{"edit":{"label":"pathId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"pathId","searchable":true,"sortable":true}},"parent":{"edit":{"label":"parent","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"parent","searchable":true,"sortable":true}},"children":{"edit":{"label":"children","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"children","searchable":false,"sortable":false}},"files":{"edit":{"label":"files","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"files","searchable":false,"sortable":false}},"path":{"edit":{"label":"path","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"path","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","pathId","parent"],"edit":[[{"name":"name","size":6},{"name":"pathId","size":4}],[{"name":"parent","size":6},{"name":"children","size":6}],[{"name":"files","size":6},{"name":"path","size":6}]]},"uid":"plugin::upload.folder"}', 'object', NULL, NULL),
(15, 'plugin_content_manager_configuration_content_types::plugin::i18n.locale', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"code":{"edit":{"label":"code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"code","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","createdAt"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}]]},"uid":"plugin::i18n.locale"}', 'object', NULL, NULL),
(16, 'plugin_content_manager_configuration_content_types::plugin::users-permissions.permission', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","role","createdAt"],"edit":[[{"name":"action","size":6},{"name":"role","size":6}]]},"uid":"plugin::users-permissions.permission"}', 'object', NULL, NULL),
(17, 'plugin_content_manager_configuration_content_types::plugin::users-permissions.user', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"username","defaultSortBy":"username","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"username":{"edit":{"label":"username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"username","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"provider":{"edit":{"label":"provider","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"provider","searchable":true,"sortable":true}},"password":{"edit":{"label":"password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"resetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"resetPasswordToken","searchable":true,"sortable":true}},"confirmationToken":{"edit":{"label":"confirmationToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"confirmationToken","searchable":true,"sortable":true}},"confirmed":{"edit":{"label":"confirmed","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"confirmed","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"blocked","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","confirmed"],"edit":[[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"confirmed","size":4}],[{"name":"blocked","size":4},{"name":"role","size":6}]]},"uid":"plugin::users-permissions.user"}', 'object', NULL, NULL),
(18, 'plugin_content_manager_configuration_content_types::plugin::users-permissions.role', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"users":{"edit":{"label":"users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"users","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6},{"name":"permissions","size":6}],[{"name":"users","size":6}]]},"uid":"plugin::users-permissions.role"}', 'object', NULL, NULL),
(19, 'plugin_upload_settings', '{"sizeOptimization":true,"responsiveDimensions":true,"autoOrientation":false}', 'object', NULL, NULL),
(20, 'plugin_upload_view_configuration', '{"pageSize":10,"sort":"createdAt:DESC"}', 'object', NULL, NULL),
(21, 'plugin_upload_metrics', '{"weeklySchedule":"18 25 14 * * 4","lastWeeklyUpdate":1714652718215}', 'object', NULL, NULL),
(22, 'plugin_i18n_default_locale', '"en"', 'string', NULL, NULL),
(23, 'plugin_users-permissions_grant', '{"email":{"enabled":true,"icon":"envelope"},"discord":{"enabled":false,"icon":"discord","key":"","secret":"","callback":"api/auth/discord/callback","scope":["identify","email"]},"facebook":{"enabled":false,"icon":"facebook-square","key":"","secret":"","callback":"api/auth/facebook/callback","scope":["email"]},"google":{"enabled":false,"icon":"google","key":"","secret":"","callback":"api/auth/google/callback","scope":["email"]},"github":{"enabled":false,"icon":"github","key":"","secret":"","callback":"api/auth/github/callback","scope":["user","user:email"]},"microsoft":{"enabled":false,"icon":"windows","key":"","secret":"","callback":"api/auth/microsoft/callback","scope":["user.read"]},"twitter":{"enabled":false,"icon":"twitter","key":"","secret":"","callback":"api/auth/twitter/callback"},"instagram":{"enabled":false,"icon":"instagram","key":"","secret":"","callback":"api/auth/instagram/callback","scope":["user_profile"]},"vk":{"enabled":false,"icon":"vk","key":"","secret":"","callback":"api/auth/vk/callback","scope":["email"]},"twitch":{"enabled":false,"icon":"twitch","key":"","secret":"","callback":"api/auth/twitch/callback","scope":["user:read:email"]},"linkedin":{"enabled":false,"icon":"linkedin","key":"","secret":"","callback":"api/auth/linkedin/callback","scope":["r_liteprofile","r_emailaddress"]},"cognito":{"enabled":false,"icon":"aws","key":"","secret":"","subdomain":"my.subdomain.com","callback":"api/auth/cognito/callback","scope":["email","openid","profile"]},"reddit":{"enabled":false,"icon":"reddit","key":"","secret":"","state":true,"callback":"api/auth/reddit/callback","scope":["identity"]},"auth0":{"enabled":false,"icon":"","key":"","secret":"","subdomain":"my-tenant.eu","callback":"api/auth/auth0/callback","scope":["openid","email","profile"]},"cas":{"enabled":false,"icon":"book","key":"","secret":"","callback":"api/auth/cas/callback","scope":["openid email"],"subdomain":"my.subdomain.com/cas"},"patreon":{"enabled":false,"icon":"","key":"","secret":"","callback":"api/auth/patreon/callback","scope":["identity","identity[email]"]},"keycloak":{"enabled":false,"icon":"","key":"","secret":"","subdomain":"myKeycloakProvider.com/realms/myrealm","callback":"api/auth/keycloak/callback","scope":["openid","email","profile"]}}', 'object', NULL, NULL),
(24, 'plugin_users-permissions_email', '{"reset_password":{"display":"Email.template.reset_password","icon":"sync","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Reset password","message":"<p>We heard that you lost your password. Sorry about that!</p>\n\n<p>But don’t worry! You can use the following link to reset your password:</p>\n<p><%= URL %>?code=<%= TOKEN %></p>\n\n<p>Thanks.</p>"}},"email_confirmation":{"display":"Email.template.email_confirmation","icon":"check-square","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Account confirmation","message":"<p>Thank you for registering!</p>\n\n<p>You have to confirm your email address. Please click on the link below.</p>\n\n<p><%= URL %>?confirmation=<%= CODE %></p>\n\n<p>Thanks.</p>"}}}', 'object', NULL, NULL),
(25, 'plugin_users-permissions_advanced', '{"unique_email":true,"allow_register":true,"email_confirmation":false,"email_reset_password":null,"email_confirmation_redirection":null,"default_role":"authenticated"}', 'object', NULL, NULL),
(26, 'core_admin_auth', '{"providers":{"autoRegister":false,"defaultRole":null,"ssoLockedRoles":null}}', 'object', NULL, NULL),
(27, 'plugin_content_manager_configuration_components::landing-page.teaser', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"Headline","defaultSortBy":"Headline","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"Headline":{"edit":{"label":"Headline","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Headline","searchable":true,"sortable":true}},"ContentCard":{"edit":{"label":"ContentCard","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ContentCard","searchable":false,"sortable":false}}},"layouts":{"list":["id","Headline","ContentCard"],"edit":[[{"name":"Headline","size":6}],[{"name":"ContentCard","size":12}]]},"uid":"landing-page.teaser","isComponent":true}', 'object', NULL, NULL),
(30, 'plugin_content_manager_configuration_components::landing-page.ga-search', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"Headline","defaultSortBy":"Headline","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"Headline":{"edit":{"label":"Headline","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Headline","searchable":true,"sortable":true}},"Copy":{"edit":{"label":"Copy","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Copy","searchable":true,"sortable":true}},"Ctas":{"edit":{"label":"Ctas","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Ctas","searchable":false,"sortable":false}}},"layouts":{"list":["id","Headline","Copy","Ctas"],"edit":[[{"name":"Headline","size":6},{"name":"Copy","size":6}],[{"name":"Ctas","size":12}]]},"uid":"landing-page.ga-search","isComponent":true}', 'object', NULL, NULL),
(32, 'plugin_content_manager_configuration_components::landing-page.button-teaser', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"Headline","defaultSortBy":"Headline","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"Headline":{"edit":{"label":"Headline","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Headline","searchable":true,"sortable":true}},"Subline":{"edit":{"label":"Subline","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Subline","searchable":true,"sortable":true}},"ButtonCard":{"edit":{"label":"ButtonCard","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ButtonCard","searchable":false,"sortable":false}}},"layouts":{"list":["id","Headline","Subline","ButtonCard"],"edit":[[{"name":"Headline","size":6},{"name":"Subline","size":6}],[{"name":"ButtonCard","size":12}]]},"uid":"landing-page.button-teaser","isComponent":true}', 'object', NULL, NULL),
(33, 'plugin_content_manager_configuration_content_types::api::landing-page.landing-page', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"Title","defaultSortBy":"Title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"Title":{"edit":{"label":"Title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Title","searchable":true,"sortable":true}},"Slug":{"edit":{"label":"Slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Slug","searchable":true,"sortable":true}},"Body":{"edit":{"label":"Body","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Body","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"list":["id","Title","Slug","createdAt"],"edit":[[{"name":"Title","size":6},{"name":"Slug","size":6}],[{"name":"Body","size":12}]]},"uid":"api::landing-page.landing-page"}', 'object', NULL, NULL),
(37, 'plugin_content_manager_configuration_components::blocks.button-cards', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"Label","defaultSortBy":"Label","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"Label":{"edit":{"label":"Label","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Label","searchable":true,"sortable":true}},"Icon":{"edit":{"label":"Icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Icon","searchable":false,"sortable":false}},"Url":{"edit":{"label":"Url","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Url","searchable":true,"sortable":true}}},"layouts":{"list":["id","Label","Icon","Url"],"edit":[[{"name":"Label","size":6}],[{"name":"Icon","size":12}],[{"name":"Url","size":6}]]},"uid":"blocks.button-cards","isComponent":true}', 'object', NULL, NULL),
(38, 'plugin_content_manager_configuration_components::blocks.content-card', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"Headline","defaultSortBy":"Headline","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"Headline":{"edit":{"label":"Headline","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Headline","searchable":true,"sortable":true}},"Icon":{"edit":{"label":"Icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Icon","searchable":false,"sortable":false}},"Copy":{"edit":{"label":"Copy","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Copy","searchable":true,"sortable":true}}},"layouts":{"list":["id","Headline","Icon","Copy"],"edit":[[{"name":"Headline","size":6}],[{"name":"Icon","size":12}],[{"name":"Copy","size":6}]]},"uid":"blocks.content-card","isComponent":true}', 'object', NULL, NULL),
(39, 'plugin_content_manager_configuration_components::blocks.icons', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"Label","defaultSortBy":"Label","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"Label":{"edit":{"label":"Label","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Label","searchable":true,"sortable":true}},"Slug":{"edit":{"label":"Slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Slug","searchable":true,"sortable":true}},"SVG":{"edit":{"label":"SVG","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"SVG","searchable":false,"sortable":false}},"Direction":{"edit":{"label":"Direction","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Direction","searchable":true,"sortable":true}}},"layouts":{"list":["id","Label","Slug","SVG"],"edit":[[{"name":"Label","size":6},{"name":"Slug","size":6}],[{"name":"SVG","size":6},{"name":"Direction","size":6}]]},"uid":"blocks.icons","isComponent":true}', 'object', NULL, NULL),
(40, 'plugin_content_manager_configuration_components::landing-page.stage', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"Headline","defaultSortBy":"Headline","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"Headline":{"edit":{"label":"Headline","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Headline","searchable":true,"sortable":true}},"Subline":{"edit":{"label":"Subline","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Subline","searchable":true,"sortable":true}},"Ctas":{"edit":{"label":"Ctas","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Ctas","searchable":false,"sortable":false}},"BackgroundImage":{"edit":{"label":"BackgroundImage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"BackgroundImage","searchable":false,"sortable":false}},"Logo":{"edit":{"label":"Logo","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Logo","searchable":false,"sortable":false}}},"layouts":{"list":["id","Headline","Subline","BackgroundImage"],"edit":[[{"name":"Headline","size":6},{"name":"Subline","size":6}],[{"name":"BackgroundImage","size":6},{"name":"Logo","size":6}],[{"name":"Ctas","size":12}]]},"uid":"landing-page.stage","isComponent":true}', 'object', NULL, NULL),
(41, 'plugin_content_manager_configuration_components::blocks.cta', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"Label","defaultSortBy":"Label","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":false,"sortable":false}},"Label":{"edit":{"label":"Label","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Label","searchable":true,"sortable":true}},"Href":{"edit":{"label":"Href","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Href","searchable":true,"sortable":true}},"Type":{"edit":{"label":"Type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Type","searchable":true,"sortable":true}},"Icon":{"edit":{"label":"Icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Icon","searchable":false,"sortable":false}}},"layouts":{"list":["id","Label","Href","Type"],"edit":[[{"name":"Label","size":6},{"name":"Href","size":6}],[{"name":"Type","size":6}],[{"name":"Icon","size":12}]]},"uid":"blocks.cta","isComponent":true}', 'object', NULL, NULL),
(42, 'plugin_content_manager_configuration_content_types::api::health-department.health-department', '{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"Title","defaultSortBy":"Title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"Title":{"edit":{"label":"Title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Title","searchable":true,"sortable":true}},"Street":{"edit":{"label":"Street","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Street","searchable":true,"sortable":true}},"City":{"edit":{"label":"City","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"City","searchable":true,"sortable":true}},"ZIPCode":{"edit":{"label":"ZIPCode","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ZIPCode","searchable":true,"sortable":true}},"Contact":{"edit":{"label":"Contact","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Contact","searchable":true,"sortable":true}},"Phone":{"edit":{"label":"Phone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Phone","searchable":true,"sortable":true}},"Fax":{"edit":{"label":"Fax","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"Fax","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}}},"layouts":{"edit":[[{"name":"Title","size":6}],[{"name":"Street","size":6}],[{"name":"ZIPCode","size":4},{"name":"City","size":6}],[{"name":"Contact","size":6}],[{"name":"Phone","size":4},{"name":"Fax","size":4}]],"list":["id","Title","Street","City"]},"uid":"api::health-department.health-department"}', 'object', NULL, NULL);

INSERT INTO "public"."strapi_database_schema" ("id", "schema", "time", "hash") VALUES
(39, '{"tables":[{"name":"strapi_core_store_settings","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"environment","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"tag","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_webhooks","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"headers","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"events","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"enabled","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_permissions","indexes":[{"name":"admin_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action_parameters","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"subject","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"properties","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"conditions","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_users","indexes":[{"name":"admin_users_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_users_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_users_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_users_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"firstname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lastname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"username","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"password","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reset_password_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"registration_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_active","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"blocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"prefered_language","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_roles","indexes":[{"name":"admin_roles_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_roles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_roles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_roles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_api_tokens","indexes":[{"name":"strapi_api_tokens_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_api_tokens_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_api_tokens_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_api_tokens_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_used_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lifespan","type":"bigInteger","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_api_token_permissions","indexes":[{"name":"strapi_api_token_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_api_token_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_api_token_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_api_token_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_transfer_tokens","indexes":[{"name":"strapi_transfer_tokens_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_transfer_tokens_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_transfer_tokens_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_transfer_tokens_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_used_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lifespan","type":"bigInteger","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_transfer_token_permissions","indexes":[{"name":"strapi_transfer_token_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_transfer_token_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_transfer_token_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_transfer_token_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"files","indexes":[{"name":"upload_files_folder_path_index","columns":["folder_path"],"type":null},{"name":"upload_files_created_at_index","columns":["created_at"],"type":null},{"name":"upload_files_updated_at_index","columns":["updated_at"],"type":null},{"name":"upload_files_name_index","columns":["name"],"type":null},{"name":"upload_files_size_index","columns":["size"],"type":null},{"name":"upload_files_ext_index","columns":["ext"],"type":null},{"name":"files_created_by_id_fk","columns":["created_by_id"]},{"name":"files_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"files_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"files_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"alternative_text","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"caption","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"width","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"height","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"formats","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hash","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"ext","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"mime","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"size","type":"decimal","args":[10,2],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"preview_url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider_metadata","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"folder_path","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"upload_folders","indexes":[{"name":"upload_folders_path_id_index","columns":["path_id"],"type":"unique"},{"name":"upload_folders_path_index","columns":["path"],"type":"unique"},{"name":"upload_folders_created_by_id_fk","columns":["created_by_id"]},{"name":"upload_folders_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"upload_folders_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"upload_folders_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"path_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"path","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_releases","indexes":[{"name":"strapi_releases_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_releases_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_releases_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_releases_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"released_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"scheduled_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"timezone","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_release_actions","indexes":[{"name":"strapi_release_actions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_release_actions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_release_actions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_release_actions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"target_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"target_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_entry_valid","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"i18n_locale","indexes":[{"name":"i18n_locale_created_by_id_fk","columns":["created_by_id"]},{"name":"i18n_locale_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"i18n_locale_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"i18n_locale_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_permissions","indexes":[{"name":"up_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"up_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_roles","indexes":[{"name":"up_roles_created_by_id_fk","columns":["created_by_id"]},{"name":"up_roles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_roles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_roles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_users","indexes":[{"name":"up_users_created_by_id_fk","columns":["created_by_id"]},{"name":"up_users_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_users_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_users_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"username","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"password","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reset_password_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmation_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmed","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"blocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"articles","indexes":[{"type":"unique","name":"articles_slug_unique","columns":["slug"]},{"name":"articles_created_by_id_fk","columns":["created_by_id"]},{"name":"articles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"articles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"articles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false,"unique":true},{"name":"body","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"global_articles","indexes":[{"type":"unique","name":"global_articles_slug_unique","columns":["slug"]},{"name":"global_articles_created_by_id_fk","columns":["created_by_id"]},{"name":"global_articles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"global_articles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"global_articles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false,"unique":true},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"health_departments","indexes":[{"name":"health_departments_created_by_id_fk","columns":["created_by_id"]},{"name":"health_departments_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"health_departments_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"health_departments_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"street","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"city","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"contact","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"phone","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"fax","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"zip_code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"landing_pages","indexes":[{"type":"unique","name":"landing_pages_slug_unique","columns":["slug"]},{"name":"landing_pages_created_by_id_fk","columns":["created_by_id"]},{"name":"landing_pages_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"landing_pages_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"landing_pages_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false,"unique":true},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"components_landing_page_button_cards","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"label","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"components_landing_page_content_cards","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"headline","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"copy","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"components_blocks_ctas","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"label","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"href","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"components_atoms_icons","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"label","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"direction","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"components_landing_page_button_teasers","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"headline","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"subline","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"components_landing_page_ga_searches","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"headline","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"copy","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"components_landing_page_stages","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"headline","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"subline","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"components_landing_page_teasers","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"headline","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_permissions_role_links","indexes":[{"name":"admin_permissions_role_links_fk","columns":["permission_id"]},{"name":"admin_permissions_role_links_inv_fk","columns":["role_id"]},{"name":"admin_permissions_role_links_unique","columns":["permission_id","role_id"],"type":"unique"},{"name":"admin_permissions_role_links_order_inv_fk","columns":["permission_order"]}],"foreignKeys":[{"name":"admin_permissions_role_links_fk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"admin_permissions","onDelete":"CASCADE"},{"name":"admin_permissions_role_links_inv_fk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"admin_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_users_roles_links","indexes":[{"name":"admin_users_roles_links_fk","columns":["user_id"]},{"name":"admin_users_roles_links_inv_fk","columns":["role_id"]},{"name":"admin_users_roles_links_unique","columns":["user_id","role_id"],"type":"unique"},{"name":"admin_users_roles_links_order_fk","columns":["role_order"]},{"name":"admin_users_roles_links_order_inv_fk","columns":["user_order"]}],"foreignKeys":[{"name":"admin_users_roles_links_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"admin_users","onDelete":"CASCADE"},{"name":"admin_users_roles_links_inv_fk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"admin_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_api_token_permissions_token_links","indexes":[{"name":"strapi_api_token_permissions_token_links_fk","columns":["api_token_permission_id"]},{"name":"strapi_api_token_permissions_token_links_inv_fk","columns":["api_token_id"]},{"name":"strapi_api_token_permissions_token_links_unique","columns":["api_token_permission_id","api_token_id"],"type":"unique"},{"name":"strapi_api_token_permissions_token_links_order_inv_fk","columns":["api_token_permission_order"]}],"foreignKeys":[{"name":"strapi_api_token_permissions_token_links_fk","columns":["api_token_permission_id"],"referencedColumns":["id"],"referencedTable":"strapi_api_token_permissions","onDelete":"CASCADE"},{"name":"strapi_api_token_permissions_token_links_inv_fk","columns":["api_token_id"],"referencedColumns":["id"],"referencedTable":"strapi_api_tokens","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"api_token_permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"api_token_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"api_token_permission_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_transfer_token_permissions_token_links","indexes":[{"name":"strapi_transfer_token_permissions_token_links_fk","columns":["transfer_token_permission_id"]},{"name":"strapi_transfer_token_permissions_token_links_inv_fk","columns":["transfer_token_id"]},{"name":"strapi_transfer_token_permissions_token_links_unique","columns":["transfer_token_permission_id","transfer_token_id"],"type":"unique"},{"name":"strapi_transfer_token_permissions_token_links_order_inv_fk","columns":["transfer_token_permission_order"]}],"foreignKeys":[{"name":"strapi_transfer_token_permissions_token_links_fk","columns":["transfer_token_permission_id"],"referencedColumns":["id"],"referencedTable":"strapi_transfer_token_permissions","onDelete":"CASCADE"},{"name":"strapi_transfer_token_permissions_token_links_inv_fk","columns":["transfer_token_id"],"referencedColumns":["id"],"referencedTable":"strapi_transfer_tokens","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"transfer_token_permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"transfer_token_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"transfer_token_permission_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"files_related_morphs","indexes":[{"name":"files_related_morphs_fk","columns":["file_id"]},{"name":"files_related_morphs_order_index","columns":["order"]},{"name":"files_related_morphs_id_column_index","columns":["related_id"]}],"foreignKeys":[{"name":"files_related_morphs_fk","columns":["file_id"],"referencedColumns":["id"],"referencedTable":"files","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"file_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"related_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"related_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"files_folder_links","indexes":[{"name":"files_folder_links_fk","columns":["file_id"]},{"name":"files_folder_links_inv_fk","columns":["folder_id"]},{"name":"files_folder_links_unique","columns":["file_id","folder_id"],"type":"unique"},{"name":"files_folder_links_order_inv_fk","columns":["file_order"]}],"foreignKeys":[{"name":"files_folder_links_fk","columns":["file_id"],"referencedColumns":["id"],"referencedTable":"files","onDelete":"CASCADE"},{"name":"files_folder_links_inv_fk","columns":["folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"file_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"file_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"upload_folders_parent_links","indexes":[{"name":"upload_folders_parent_links_fk","columns":["folder_id"]},{"name":"upload_folders_parent_links_inv_fk","columns":["inv_folder_id"]},{"name":"upload_folders_parent_links_unique","columns":["folder_id","inv_folder_id"],"type":"unique"},{"name":"upload_folders_parent_links_order_inv_fk","columns":["folder_order"]}],"foreignKeys":[{"name":"upload_folders_parent_links_fk","columns":["folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"},{"name":"upload_folders_parent_links_inv_fk","columns":["inv_folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"inv_folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"folder_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_release_actions_release_links","indexes":[{"name":"strapi_release_actions_release_links_fk","columns":["release_action_id"]},{"name":"strapi_release_actions_release_links_inv_fk","columns":["release_id"]},{"name":"strapi_release_actions_release_links_unique","columns":["release_action_id","release_id"],"type":"unique"},{"name":"strapi_release_actions_release_links_order_inv_fk","columns":["release_action_order"]}],"foreignKeys":[{"name":"strapi_release_actions_release_links_fk","columns":["release_action_id"],"referencedColumns":["id"],"referencedTable":"strapi_release_actions","onDelete":"CASCADE"},{"name":"strapi_release_actions_release_links_inv_fk","columns":["release_id"],"referencedColumns":["id"],"referencedTable":"strapi_releases","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"release_action_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"release_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"release_action_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_permissions_role_links","indexes":[{"name":"up_permissions_role_links_fk","columns":["permission_id"]},{"name":"up_permissions_role_links_inv_fk","columns":["role_id"]},{"name":"up_permissions_role_links_unique","columns":["permission_id","role_id"],"type":"unique"},{"name":"up_permissions_role_links_order_inv_fk","columns":["permission_order"]}],"foreignKeys":[{"name":"up_permissions_role_links_fk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"up_permissions","onDelete":"CASCADE"},{"name":"up_permissions_role_links_inv_fk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"up_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_users_role_links","indexes":[{"name":"up_users_role_links_fk","columns":["user_id"]},{"name":"up_users_role_links_inv_fk","columns":["role_id"]},{"name":"up_users_role_links_unique","columns":["user_id","role_id"],"type":"unique"},{"name":"up_users_role_links_order_inv_fk","columns":["user_order"]}],"foreignKeys":[{"name":"up_users_role_links_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"up_users","onDelete":"CASCADE"},{"name":"up_users_role_links_inv_fk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"up_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"landing_pages_components","indexes":[{"name":"landing_pages_field_index","columns":["field"]},{"name":"landing_pages_component_type_index","columns":["component_type"]},{"name":"landing_pages_entity_fk","columns":["entity_id"]},{"name":"landing_pages_unique","columns":["entity_id","component_id","field","component_type"],"type":"unique"}],"foreignKeys":[{"name":"landing_pages_entity_fk","columns":["entity_id"],"referencedColumns":["id"],"referencedTable":"landing_pages","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"entity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"components_landing_page_button_cards_components","indexes":[{"name":"components_landing_page_button_cards_field_index","columns":["field"]},{"name":"components_landing_page_button_cards_component_type_index","columns":["component_type"]},{"name":"components_landing_page_button_cards_entity_fk","columns":["entity_id"]},{"name":"components_landing_page_button_cards_unique","columns":["entity_id","component_id","field","component_type"],"type":"unique"}],"foreignKeys":[{"name":"components_landing_page_button_cards_entity_fk","columns":["entity_id"],"referencedColumns":["id"],"referencedTable":"components_landing_page_button_cards","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"entity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"components_landing_page_content_cards_components","indexes":[{"name":"components_landing_page_content_cards_field_index","columns":["field"]},{"name":"components_landing_page_content_cards_component_type_index","columns":["component_type"]},{"name":"components_landing_page_content_cards_entity_fk","columns":["entity_id"]},{"name":"components_landing_page_content_cards_unique","columns":["entity_id","component_id","field","component_type"],"type":"unique"}],"foreignKeys":[{"name":"components_landing_page_content_cards_entity_fk","columns":["entity_id"],"referencedColumns":["id"],"referencedTable":"components_landing_page_content_cards","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"entity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"components_blocks_ctas_components","indexes":[{"name":"components_blocks_ctas_field_index","columns":["field"]},{"name":"components_blocks_ctas_component_type_index","columns":["component_type"]},{"name":"components_blocks_ctas_entity_fk","columns":["entity_id"]},{"name":"components_blocks_ctas_unique","columns":["entity_id","component_id","field","component_type"],"type":"unique"}],"foreignKeys":[{"name":"components_blocks_ctas_entity_fk","columns":["entity_id"],"referencedColumns":["id"],"referencedTable":"components_blocks_ctas","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"entity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"components_landing_page_button_teasers_components","indexes":[{"name":"components_landing_page_button_teasers_field_index","columns":["field"]},{"name":"components_landing_page_button_teasers_component_type_index","columns":["component_type"]},{"name":"components_landing_page_button_teasers_entity_fk","columns":["entity_id"]},{"name":"components_landing_page_button_teasers_unique","columns":["entity_id","component_id","field","component_type"],"type":"unique"}],"foreignKeys":[{"name":"components_landing_page_button_teasers_entity_fk","columns":["entity_id"],"referencedColumns":["id"],"referencedTable":"components_landing_page_button_teasers","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"entity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"components_landing_page_ga_searches_components","indexes":[{"name":"components_landing_page_ga_searches_field_index","columns":["field"]},{"name":"components_landing_page_ga_searches_component_type_index","columns":["component_type"]},{"name":"components_landing_page_ga_searches_entity_fk","columns":["entity_id"]},{"name":"components_landing_page_ga_searches_unique","columns":["entity_id","component_id","field","component_type"],"type":"unique"}],"foreignKeys":[{"name":"components_landing_page_ga_searches_entity_fk","columns":["entity_id"],"referencedColumns":["id"],"referencedTable":"components_landing_page_ga_searches","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"entity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"components_landing_page_stages_components","indexes":[{"name":"components_landing_page_stages_field_index","columns":["field"]},{"name":"components_landing_page_stages_component_type_index","columns":["component_type"]},{"name":"components_landing_page_stages_entity_fk","columns":["entity_id"]},{"name":"components_landing_page_stages_unique","columns":["entity_id","component_id","field","component_type"],"type":"unique"}],"foreignKeys":[{"name":"components_landing_page_stages_entity_fk","columns":["entity_id"],"referencedColumns":["id"],"referencedTable":"components_landing_page_stages","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"entity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"components_landing_page_teasers_components","indexes":[{"name":"components_landing_page_teasers_field_index","columns":["field"]},{"name":"components_landing_page_teasers_component_type_index","columns":["component_type"]},{"name":"components_landing_page_teasers_entity_fk","columns":["entity_id"]},{"name":"components_landing_page_teasers_unique","columns":["entity_id","component_id","field","component_type"],"type":"unique"}],"foreignKeys":[{"name":"components_landing_page_teasers_entity_fk","columns":["entity_id"],"referencedColumns":["id"],"referencedTable":"components_landing_page_teasers","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"entity_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"component_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]}]}', '2024-05-02 17:46:35.873', 'b8cbc66120bda8501e5454b005b8aeae');

INSERT INTO "public"."up_permissions" ("id", "action", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, 'plugin::users-permissions.auth.changePassword', '2024-05-02 14:15:54.42', '2024-05-02 14:15:54.42', NULL, NULL),
(2, 'plugin::users-permissions.user.me', '2024-05-02 14:15:54.42', '2024-05-02 14:15:54.42', NULL, NULL),
(3, 'plugin::users-permissions.auth.callback', '2024-05-02 14:15:54.711', '2024-05-02 14:15:54.711', NULL, NULL),
(4, 'plugin::users-permissions.auth.forgotPassword', '2024-05-02 14:15:54.711', '2024-05-02 14:15:54.711', NULL, NULL),
(5, 'plugin::users-permissions.auth.resetPassword', '2024-05-02 14:15:54.711', '2024-05-02 14:15:54.711', NULL, NULL),
(6, 'plugin::users-permissions.auth.connect', '2024-05-02 14:15:54.711', '2024-05-02 14:15:54.711', NULL, NULL),
(7, 'plugin::users-permissions.auth.register', '2024-05-02 14:15:54.711', '2024-05-02 14:15:54.711', NULL, NULL),
(8, 'plugin::users-permissions.auth.emailConfirmation', '2024-05-02 14:15:54.711', '2024-05-02 14:15:54.711', NULL, NULL),
(9, 'plugin::users-permissions.auth.sendEmailConfirmation', '2024-05-02 14:15:54.711', '2024-05-02 14:15:54.711', NULL, NULL),
(10, 'api::article.article.find', '2024-05-02 17:54:16.776', '2024-05-02 17:54:16.776', NULL, NULL),
(11, 'api::article.article.findOne', '2024-05-02 17:54:16.776', '2024-05-02 17:54:16.776', NULL, NULL),
(12, 'api::global-article.global-article.findOne', '2024-05-02 17:54:16.776', '2024-05-02 17:54:16.776', NULL, NULL),
(13, 'api::global-article.global-article.find', '2024-05-02 17:54:16.776', '2024-05-02 17:54:16.776', NULL, NULL),
(14, 'api::landing-page.landing-page.find', '2024-05-02 17:54:16.776', '2024-05-02 17:54:16.776', NULL, NULL),
(15, 'plugin::content-type-builder.components.getComponents', '2024-05-02 17:54:16.776', '2024-05-02 17:54:16.776', NULL, NULL),
(16, 'plugin::content-type-builder.components.getComponent', '2024-05-02 17:54:16.776', '2024-05-02 17:54:16.776', NULL, NULL),
(17, 'api::landing-page.landing-page.findOne', '2024-05-02 17:54:16.776', '2024-05-02 17:54:16.776', NULL, NULL),
(18, 'plugin::content-type-builder.content-types.getContentTypes', '2024-05-02 17:54:16.776', '2024-05-02 17:54:16.776', NULL, NULL),
(19, 'plugin::upload.content-api.find', '2024-05-02 17:54:16.777', '2024-05-02 17:54:16.777', NULL, NULL),
(20, 'plugin::content-type-builder.content-types.getContentType', '2024-05-02 17:54:16.777', '2024-05-02 17:54:16.777', NULL, NULL),
(21, 'plugin::upload.content-api.findOne', '2024-05-02 17:54:16.777', '2024-05-02 17:54:16.777', NULL, NULL),
(22, 'api::article.article.find', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(23, 'api::article.article.findOne', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(24, 'api::article.article.create', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(25, 'api::article.article.update', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(26, 'api::global-article.global-article.find', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(27, 'api::article.article.delete', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(28, 'api::global-article.global-article.findOne', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(29, 'api::global-article.global-article.create', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(30, 'api::health-department.health-department.create', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(31, 'api::global-article.global-article.delete', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(32, 'api::health-department.health-department.find', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(33, 'api::global-article.global-article.update', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(34, 'api::health-department.health-department.findOne', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(35, 'api::health-department.health-department.update', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(36, 'api::landing-page.landing-page.update', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(37, 'plugin::content-type-builder.components.getComponents', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(38, 'api::landing-page.landing-page.find', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(39, 'api::health-department.health-department.delete', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(40, 'api::landing-page.landing-page.findOne', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(41, 'api::landing-page.landing-page.create', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(42, 'plugin::content-type-builder.content-types.getContentTypes', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(43, 'api::landing-page.landing-page.delete', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(44, 'plugin::content-type-builder.components.getComponent', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(45, 'plugin::content-type-builder.content-types.getContentType', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(46, 'plugin::upload.content-api.upload', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(47, 'plugin::upload.content-api.findOne', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(48, 'plugin::upload.content-api.find', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL),
(49, 'plugin::upload.content-api.destroy', '2024-05-02 17:56:49.371', '2024-05-02 17:56:49.371', NULL, NULL);

INSERT INTO "public"."up_permissions_role_links" ("id", "permission_id", "role_id", "permission_order") VALUES
(1, 2, 1, 1),
(2, 1, 1, 1),
(3, 5, 2, 1),
(4, 7, 2, 1),
(5, 4, 2, 1),
(6, 3, 2, 1),
(7, 6, 2, 1),
(8, 9, 2, 1),
(9, 8, 2, 1),
(10, 12, 2, 2),
(11, 10, 2, 2),
(12, 11, 2, 2),
(13, 13, 2, 2),
(14, 14, 2, 2),
(15, 15, 2, 2),
(16, 17, 2, 2),
(17, 18, 2, 3),
(18, 16, 2, 2),
(19, 21, 2, 3),
(20, 19, 2, 3),
(21, 20, 2, 3),
(22, 28, 1, 2),
(23, 26, 1, 2),
(24, 29, 1, 2),
(25, 23, 1, 2),
(26, 22, 1, 2),
(27, 25, 1, 2),
(28, 27, 1, 2),
(29, 24, 1, 2),
(30, 34, 1, 2),
(31, 33, 1, 3),
(32, 31, 1, 3),
(33, 32, 1, 3),
(34, 39, 1, 4),
(35, 40, 1, 4),
(36, 41, 1, 3),
(37, 30, 1, 4),
(38, 35, 1, 3),
(39, 38, 1, 4),
(40, 43, 1, 4),
(41, 44, 1, 4),
(42, 37, 1, 4),
(43, 48, 1, 5),
(44, 45, 1, 5),
(45, 42, 1, 5),
(46, 49, 1, 5),
(47, 36, 1, 5),
(48, 47, 1, 5),
(49, 46, 1, 5);

INSERT INTO "public"."up_roles" ("id", "name", "description", "type", "created_at", "updated_at", "created_by_id", "updated_by_id") VALUES
(1, 'Authenticated', 'Default role given to authenticated user.', 'authenticated', '2024-05-02 14:15:54.054', '2024-05-02 17:56:49.15', NULL, NULL),
(2, 'Public', 'Default role given to unauthenticated user.', 'public', '2024-05-02 14:15:54.214', '2024-05-02 17:54:16.555', NULL, NULL);

ALTER TABLE "public"."admin_permissions" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."admin_permissions" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX admin_permissions_created_by_id_fk ON public.admin_permissions USING btree (created_by_id);
CREATE INDEX admin_permissions_updated_by_id_fk ON public.admin_permissions USING btree (updated_by_id);
ALTER TABLE "public"."admin_permissions_role_links" ADD FOREIGN KEY ("role_id") REFERENCES "public"."admin_roles"("id") ON DELETE CASCADE;
ALTER TABLE "public"."admin_permissions_role_links" ADD FOREIGN KEY ("permission_id") REFERENCES "public"."admin_permissions"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX admin_permissions_role_links_fk ON public.admin_permissions_role_links USING btree (permission_id);
CREATE INDEX admin_permissions_role_links_inv_fk ON public.admin_permissions_role_links USING btree (role_id);
CREATE UNIQUE INDEX admin_permissions_role_links_unique ON public.admin_permissions_role_links USING btree (permission_id, role_id);
CREATE INDEX admin_permissions_role_links_order_inv_fk ON public.admin_permissions_role_links USING btree (permission_order);
ALTER TABLE "public"."admin_roles" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."admin_roles" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX admin_roles_created_by_id_fk ON public.admin_roles USING btree (created_by_id);
CREATE INDEX admin_roles_updated_by_id_fk ON public.admin_roles USING btree (updated_by_id);
ALTER TABLE "public"."admin_users" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."admin_users" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX admin_users_created_by_id_fk ON public.admin_users USING btree (created_by_id);
CREATE INDEX admin_users_updated_by_id_fk ON public.admin_users USING btree (updated_by_id);
ALTER TABLE "public"."admin_users_roles_links" ADD FOREIGN KEY ("user_id") REFERENCES "public"."admin_users"("id") ON DELETE CASCADE;
ALTER TABLE "public"."admin_users_roles_links" ADD FOREIGN KEY ("role_id") REFERENCES "public"."admin_roles"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX admin_users_roles_links_fk ON public.admin_users_roles_links USING btree (user_id);
CREATE INDEX admin_users_roles_links_inv_fk ON public.admin_users_roles_links USING btree (role_id);
CREATE UNIQUE INDEX admin_users_roles_links_unique ON public.admin_users_roles_links USING btree (user_id, role_id);
CREATE INDEX admin_users_roles_links_order_fk ON public.admin_users_roles_links USING btree (role_order);
CREATE INDEX admin_users_roles_links_order_inv_fk ON public.admin_users_roles_links USING btree (user_order);
ALTER TABLE "public"."articles" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."articles" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE UNIQUE INDEX articles_slug_unique ON public.articles USING btree (slug);
CREATE INDEX articles_created_by_id_fk ON public.articles USING btree (created_by_id);
CREATE INDEX articles_updated_by_id_fk ON public.articles USING btree (updated_by_id);
ALTER TABLE "public"."components_blocks_ctas_components" ADD FOREIGN KEY ("entity_id") REFERENCES "public"."components_blocks_ctas"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX components_blocks_ctas_field_index ON public.components_blocks_ctas_components USING btree (field);
CREATE INDEX components_blocks_ctas_component_type_index ON public.components_blocks_ctas_components USING btree (component_type);
CREATE INDEX components_blocks_ctas_entity_fk ON public.components_blocks_ctas_components USING btree (entity_id);
CREATE UNIQUE INDEX components_blocks_ctas_unique ON public.components_blocks_ctas_components USING btree (entity_id, component_id, field, component_type);
ALTER TABLE "public"."components_landing_page_button_cards_components" ADD FOREIGN KEY ("entity_id") REFERENCES "public"."components_landing_page_button_cards"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX components_landing_page_button_cards_field_index ON public.components_landing_page_button_cards_components USING btree (field);
CREATE INDEX components_landing_page_button_cards_component_type_index ON public.components_landing_page_button_cards_components USING btree (component_type);
CREATE INDEX components_landing_page_button_cards_entity_fk ON public.components_landing_page_button_cards_components USING btree (entity_id);
CREATE UNIQUE INDEX components_landing_page_button_cards_unique ON public.components_landing_page_button_cards_components USING btree (entity_id, component_id, field, component_type);
ALTER TABLE "public"."components_landing_page_button_teasers_components" ADD FOREIGN KEY ("entity_id") REFERENCES "public"."components_landing_page_button_teasers"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX components_landing_page_button_teasers_field_index ON public.components_landing_page_button_teasers_components USING btree (field);
CREATE INDEX components_landing_page_button_teasers_component_type_index ON public.components_landing_page_button_teasers_components USING btree (component_type);
CREATE INDEX components_landing_page_button_teasers_entity_fk ON public.components_landing_page_button_teasers_components USING btree (entity_id);
CREATE UNIQUE INDEX components_landing_page_button_teasers_unique ON public.components_landing_page_button_teasers_components USING btree (entity_id, component_id, field, component_type);
ALTER TABLE "public"."components_landing_page_content_cards_components" ADD FOREIGN KEY ("entity_id") REFERENCES "public"."components_landing_page_content_cards"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX components_landing_page_content_cards_field_index ON public.components_landing_page_content_cards_components USING btree (field);
CREATE INDEX components_landing_page_content_cards_component_type_index ON public.components_landing_page_content_cards_components USING btree (component_type);
CREATE INDEX components_landing_page_content_cards_entity_fk ON public.components_landing_page_content_cards_components USING btree (entity_id);
CREATE UNIQUE INDEX components_landing_page_content_cards_unique ON public.components_landing_page_content_cards_components USING btree (entity_id, component_id, field, component_type);
ALTER TABLE "public"."components_landing_page_ga_searches_components" ADD FOREIGN KEY ("entity_id") REFERENCES "public"."components_landing_page_ga_searches"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX components_landing_page_ga_searches_field_index ON public.components_landing_page_ga_searches_components USING btree (field);
CREATE INDEX components_landing_page_ga_searches_component_type_index ON public.components_landing_page_ga_searches_components USING btree (component_type);
CREATE INDEX components_landing_page_ga_searches_entity_fk ON public.components_landing_page_ga_searches_components USING btree (entity_id);
CREATE UNIQUE INDEX components_landing_page_ga_searches_unique ON public.components_landing_page_ga_searches_components USING btree (entity_id, component_id, field, component_type);
ALTER TABLE "public"."components_landing_page_stages_components" ADD FOREIGN KEY ("entity_id") REFERENCES "public"."components_landing_page_stages"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX components_landing_page_stages_field_index ON public.components_landing_page_stages_components USING btree (field);
CREATE INDEX components_landing_page_stages_component_type_index ON public.components_landing_page_stages_components USING btree (component_type);
CREATE INDEX components_landing_page_stages_entity_fk ON public.components_landing_page_stages_components USING btree (entity_id);
CREATE UNIQUE INDEX components_landing_page_stages_unique ON public.components_landing_page_stages_components USING btree (entity_id, component_id, field, component_type);
ALTER TABLE "public"."components_landing_page_teasers_components" ADD FOREIGN KEY ("entity_id") REFERENCES "public"."components_landing_page_teasers"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX components_landing_page_teasers_field_index ON public.components_landing_page_teasers_components USING btree (field);
CREATE INDEX components_landing_page_teasers_component_type_index ON public.components_landing_page_teasers_components USING btree (component_type);
CREATE INDEX components_landing_page_teasers_entity_fk ON public.components_landing_page_teasers_components USING btree (entity_id);
CREATE UNIQUE INDEX components_landing_page_teasers_unique ON public.components_landing_page_teasers_components USING btree (entity_id, component_id, field, component_type);
ALTER TABLE "public"."files" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."files" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX upload_files_folder_path_index ON public.files USING btree (folder_path);
CREATE INDEX upload_files_created_at_index ON public.files USING btree (created_at);
CREATE INDEX upload_files_updated_at_index ON public.files USING btree (updated_at);
CREATE INDEX upload_files_name_index ON public.files USING btree (name);
CREATE INDEX upload_files_size_index ON public.files USING btree (size);
CREATE INDEX upload_files_ext_index ON public.files USING btree (ext);
CREATE INDEX files_created_by_id_fk ON public.files USING btree (created_by_id);
CREATE INDEX files_updated_by_id_fk ON public.files USING btree (updated_by_id);
ALTER TABLE "public"."files_folder_links" ADD FOREIGN KEY ("folder_id") REFERENCES "public"."upload_folders"("id") ON DELETE CASCADE;
ALTER TABLE "public"."files_folder_links" ADD FOREIGN KEY ("file_id") REFERENCES "public"."files"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX files_folder_links_fk ON public.files_folder_links USING btree (file_id);
CREATE INDEX files_folder_links_inv_fk ON public.files_folder_links USING btree (folder_id);
CREATE UNIQUE INDEX files_folder_links_unique ON public.files_folder_links USING btree (file_id, folder_id);
CREATE INDEX files_folder_links_order_inv_fk ON public.files_folder_links USING btree (file_order);
ALTER TABLE "public"."files_related_morphs" ADD FOREIGN KEY ("file_id") REFERENCES "public"."files"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX files_related_morphs_fk ON public.files_related_morphs USING btree (file_id);
CREATE INDEX files_related_morphs_order_index ON public.files_related_morphs USING btree ("order");
CREATE INDEX files_related_morphs_id_column_index ON public.files_related_morphs USING btree (related_id);
ALTER TABLE "public"."global_articles" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."global_articles" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE UNIQUE INDEX global_articles_slug_unique ON public.global_articles USING btree (slug);
CREATE INDEX global_articles_created_by_id_fk ON public.global_articles USING btree (created_by_id);
CREATE INDEX global_articles_updated_by_id_fk ON public.global_articles USING btree (updated_by_id);
ALTER TABLE "public"."health_departments" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."health_departments" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX health_departments_created_by_id_fk ON public.health_departments USING btree (created_by_id);
CREATE INDEX health_departments_updated_by_id_fk ON public.health_departments USING btree (updated_by_id);
ALTER TABLE "public"."i18n_locale" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."i18n_locale" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX i18n_locale_created_by_id_fk ON public.i18n_locale USING btree (created_by_id);
CREATE INDEX i18n_locale_updated_by_id_fk ON public.i18n_locale USING btree (updated_by_id);
ALTER TABLE "public"."landing_pages" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."landing_pages" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE UNIQUE INDEX landing_pages_slug_unique ON public.landing_pages USING btree (slug);
CREATE INDEX landing_pages_created_by_id_fk ON public.landing_pages USING btree (created_by_id);
CREATE INDEX landing_pages_updated_by_id_fk ON public.landing_pages USING btree (updated_by_id);
ALTER TABLE "public"."landing_pages_components" ADD FOREIGN KEY ("entity_id") REFERENCES "public"."landing_pages"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX landing_pages_field_index ON public.landing_pages_components USING btree (field);
CREATE INDEX landing_pages_component_type_index ON public.landing_pages_components USING btree (component_type);
CREATE INDEX landing_pages_entity_fk ON public.landing_pages_components USING btree (entity_id);
CREATE UNIQUE INDEX landing_pages_unique ON public.landing_pages_components USING btree (entity_id, component_id, field, component_type);
ALTER TABLE "public"."strapi_api_token_permissions" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."strapi_api_token_permissions" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX strapi_api_token_permissions_created_by_id_fk ON public.strapi_api_token_permissions USING btree (created_by_id);
CREATE INDEX strapi_api_token_permissions_updated_by_id_fk ON public.strapi_api_token_permissions USING btree (updated_by_id);
ALTER TABLE "public"."strapi_api_token_permissions_token_links" ADD FOREIGN KEY ("api_token_permission_id") REFERENCES "public"."strapi_api_token_permissions"("id") ON DELETE CASCADE;
ALTER TABLE "public"."strapi_api_token_permissions_token_links" ADD FOREIGN KEY ("api_token_id") REFERENCES "public"."strapi_api_tokens"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX strapi_api_token_permissions_token_links_fk ON public.strapi_api_token_permissions_token_links USING btree (api_token_permission_id);
CREATE INDEX strapi_api_token_permissions_token_links_inv_fk ON public.strapi_api_token_permissions_token_links USING btree (api_token_id);
CREATE UNIQUE INDEX strapi_api_token_permissions_token_links_unique ON public.strapi_api_token_permissions_token_links USING btree (api_token_permission_id, api_token_id);
CREATE INDEX strapi_api_token_permissions_token_links_order_inv_fk ON public.strapi_api_token_permissions_token_links USING btree (api_token_permission_order);
ALTER TABLE "public"."strapi_api_tokens" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."strapi_api_tokens" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX strapi_api_tokens_created_by_id_fk ON public.strapi_api_tokens USING btree (created_by_id);
CREATE INDEX strapi_api_tokens_updated_by_id_fk ON public.strapi_api_tokens USING btree (updated_by_id);
ALTER TABLE "public"."strapi_release_actions" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."strapi_release_actions" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX strapi_release_actions_created_by_id_fk ON public.strapi_release_actions USING btree (created_by_id);
CREATE INDEX strapi_release_actions_updated_by_id_fk ON public.strapi_release_actions USING btree (updated_by_id);
ALTER TABLE "public"."strapi_release_actions_release_links" ADD FOREIGN KEY ("release_id") REFERENCES "public"."strapi_releases"("id") ON DELETE CASCADE;
ALTER TABLE "public"."strapi_release_actions_release_links" ADD FOREIGN KEY ("release_action_id") REFERENCES "public"."strapi_release_actions"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX strapi_release_actions_release_links_fk ON public.strapi_release_actions_release_links USING btree (release_action_id);
CREATE INDEX strapi_release_actions_release_links_inv_fk ON public.strapi_release_actions_release_links USING btree (release_id);
CREATE UNIQUE INDEX strapi_release_actions_release_links_unique ON public.strapi_release_actions_release_links USING btree (release_action_id, release_id);
CREATE INDEX strapi_release_actions_release_links_order_inv_fk ON public.strapi_release_actions_release_links USING btree (release_action_order);
ALTER TABLE "public"."strapi_releases" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."strapi_releases" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX strapi_releases_created_by_id_fk ON public.strapi_releases USING btree (created_by_id);
CREATE INDEX strapi_releases_updated_by_id_fk ON public.strapi_releases USING btree (updated_by_id);
ALTER TABLE "public"."strapi_transfer_token_permissions" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."strapi_transfer_token_permissions" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX strapi_transfer_token_permissions_created_by_id_fk ON public.strapi_transfer_token_permissions USING btree (created_by_id);
CREATE INDEX strapi_transfer_token_permissions_updated_by_id_fk ON public.strapi_transfer_token_permissions USING btree (updated_by_id);
ALTER TABLE "public"."strapi_transfer_token_permissions_token_links" ADD FOREIGN KEY ("transfer_token_id") REFERENCES "public"."strapi_transfer_tokens"("id") ON DELETE CASCADE;
ALTER TABLE "public"."strapi_transfer_token_permissions_token_links" ADD FOREIGN KEY ("transfer_token_permission_id") REFERENCES "public"."strapi_transfer_token_permissions"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX strapi_transfer_token_permissions_token_links_fk ON public.strapi_transfer_token_permissions_token_links USING btree (transfer_token_permission_id);
CREATE INDEX strapi_transfer_token_permissions_token_links_inv_fk ON public.strapi_transfer_token_permissions_token_links USING btree (transfer_token_id);
CREATE UNIQUE INDEX strapi_transfer_token_permissions_token_links_unique ON public.strapi_transfer_token_permissions_token_links USING btree (transfer_token_permission_id, transfer_token_id);
CREATE INDEX strapi_transfer_token_permissions_token_links_order_inv_fk ON public.strapi_transfer_token_permissions_token_links USING btree (transfer_token_permission_order);
ALTER TABLE "public"."strapi_transfer_tokens" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."strapi_transfer_tokens" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX strapi_transfer_tokens_created_by_id_fk ON public.strapi_transfer_tokens USING btree (created_by_id);
CREATE INDEX strapi_transfer_tokens_updated_by_id_fk ON public.strapi_transfer_tokens USING btree (updated_by_id);
ALTER TABLE "public"."up_permissions" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."up_permissions" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX up_permissions_created_by_id_fk ON public.up_permissions USING btree (created_by_id);
CREATE INDEX up_permissions_updated_by_id_fk ON public.up_permissions USING btree (updated_by_id);
ALTER TABLE "public"."up_permissions_role_links" ADD FOREIGN KEY ("role_id") REFERENCES "public"."up_roles"("id") ON DELETE CASCADE;
ALTER TABLE "public"."up_permissions_role_links" ADD FOREIGN KEY ("permission_id") REFERENCES "public"."up_permissions"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX up_permissions_role_links_fk ON public.up_permissions_role_links USING btree (permission_id);
CREATE INDEX up_permissions_role_links_inv_fk ON public.up_permissions_role_links USING btree (role_id);
CREATE UNIQUE INDEX up_permissions_role_links_unique ON public.up_permissions_role_links USING btree (permission_id, role_id);
CREATE INDEX up_permissions_role_links_order_inv_fk ON public.up_permissions_role_links USING btree (permission_order);
ALTER TABLE "public"."up_roles" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."up_roles" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX up_roles_created_by_id_fk ON public.up_roles USING btree (created_by_id);
CREATE INDEX up_roles_updated_by_id_fk ON public.up_roles USING btree (updated_by_id);
ALTER TABLE "public"."up_users" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."up_users" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE INDEX up_users_created_by_id_fk ON public.up_users USING btree (created_by_id);
CREATE INDEX up_users_updated_by_id_fk ON public.up_users USING btree (updated_by_id);
ALTER TABLE "public"."up_users_role_links" ADD FOREIGN KEY ("role_id") REFERENCES "public"."up_roles"("id") ON DELETE CASCADE;
ALTER TABLE "public"."up_users_role_links" ADD FOREIGN KEY ("user_id") REFERENCES "public"."up_users"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX up_users_role_links_fk ON public.up_users_role_links USING btree (user_id);
CREATE INDEX up_users_role_links_inv_fk ON public.up_users_role_links USING btree (role_id);
CREATE UNIQUE INDEX up_users_role_links_unique ON public.up_users_role_links USING btree (user_id, role_id);
CREATE INDEX up_users_role_links_order_inv_fk ON public.up_users_role_links USING btree (user_order);
ALTER TABLE "public"."upload_folders" ADD FOREIGN KEY ("created_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;
ALTER TABLE "public"."upload_folders" ADD FOREIGN KEY ("updated_by_id") REFERENCES "public"."admin_users"("id") ON DELETE SET NULL;


-- Indices
CREATE UNIQUE INDEX upload_folders_path_id_index ON public.upload_folders USING btree (path_id);
CREATE UNIQUE INDEX upload_folders_path_index ON public.upload_folders USING btree (path);
CREATE INDEX upload_folders_created_by_id_fk ON public.upload_folders USING btree (created_by_id);
CREATE INDEX upload_folders_updated_by_id_fk ON public.upload_folders USING btree (updated_by_id);
ALTER TABLE "public"."upload_folders_parent_links" ADD FOREIGN KEY ("folder_id") REFERENCES "public"."upload_folders"("id") ON DELETE CASCADE;
ALTER TABLE "public"."upload_folders_parent_links" ADD FOREIGN KEY ("inv_folder_id") REFERENCES "public"."upload_folders"("id") ON DELETE CASCADE;


-- Indices
CREATE INDEX upload_folders_parent_links_fk ON public.upload_folders_parent_links USING btree (folder_id);
CREATE INDEX upload_folders_parent_links_inv_fk ON public.upload_folders_parent_links USING btree (inv_folder_id);
CREATE UNIQUE INDEX upload_folders_parent_links_unique ON public.upload_folders_parent_links USING btree (folder_id, inv_folder_id);
CREATE INDEX upload_folders_parent_links_order_inv_fk ON public.upload_folders_parent_links USING btree (folder_order);
